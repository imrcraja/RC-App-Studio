plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.rc.appstudio"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.rc.appstudio"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "0.4"
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    sourceSets {
        getByName("main") {
            java.srcDir("../shared")
            assets.srcDir(layout.buildDirectory.dir("generated/runnerAssets"))
        }
    }
    packaging {
        resources {
            excludes += setOf(
                "META-INF/versions/**", "META-INF/LICENSE*", "META-INF/DEPENDENCIES",
                "META-INF/AL2.0", "META-INF/LGPL2.1", "META-INF/INDEX.LIST", "META-INF/*.kotlin_module"
            )
        }
    }
    lint { abortOnError = false }
}

// Runner APK pehle banta hai, phir Studio ke assets me runner.apk ki tarah jud jata hai
val copyRunner = tasks.register<Copy>("copyRunnerApk") {
    dependsOn(":runner:assembleDebug")
    from(project(":runner").layout.buildDirectory.dir("outputs/apk/debug")) {
        include("*.apk")
        rename { "runner.apk" }
    }
    into(layout.buildDirectory.dir("generated/runnerAssets"))
}
tasks.named("preBuild") { dependsOn(copyRunner) }
tasks.configureEach {
    if (name.startsWith("merge") && name.endsWith("Assets")) dependsOn(copyRunner)
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("com.android.tools.build:apksig:8.5.2")
    implementation("org.bouncycastle:bcprov-jdk18on:1.78.1")
    implementation("org.bouncycastle:bcpkix-jdk18on:1.78.1")
}
