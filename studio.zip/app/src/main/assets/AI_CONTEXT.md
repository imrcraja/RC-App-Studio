# AI_CONTEXT.md  (RC App Studio)

Read this file first. It tells any AI everything needed to work with the owner and with RC App Studio projects.
Version of this file: 0.3

## 1. Owner and working environment
- Owner handle: "RC RAJA GAMER 2.0" (RC). Minecraft mod developer (Fabric, Java Edition) and app builder.
- Works ONLY from an Android phone (no PC). Build/deploy so far via GitHub Actions and Replit.
- Writes Hinglish (Hindi in English letters). Reply in the language the owner writes in. Keep answers short and copy-paste ready.
- Prefers fixes as direct copy-paste text. Whole projects may be given as a .rc (or .zip) file.
- Be honest: if you could not build or test something, say so. Never promise "anything will work". Ask for the exact build error and fix it.

## 2. What RC App Studio is
A Sketchware-like mobile IDE that runs on Android. ALL future projects of the owner live in it.
Current build (0.3) has:
- Projects: import/export .rc and .zip, file browser, text editor (paste/copy), rename/delete, new file/folder.
- App settings per project (rc-app.json): app name, package, versionName, versionCode (+/-), primary color, logo.
- AI tab: bring-your-own-key (Gemini, OpenAI, DeepSeek, Groq, OpenRouter). AI returns JSON {notes, files[]}; the owner reviews the list and taps Apply. A live activity panel shows what the AI is doing.
- Assets: offline-first (see section 5), date-wise gallery, Save/Share/Delete.
- Downloads: the app's own folder (exports, AI_CONTEXT.md). Save to any folder, Share, Import, optional cloud upload.
- Storage mode: Local / Cloud / Both. Projects always stay in the app's private files folder so they work offline. Cloud (Supabase Storage) is backup/sync.
- GitHub push (optional): uploads project.zip to a repo so GitHub Actions builds the APK.

Planned (NOT built yet, do not pretend they exist): drag-and-drop UI designer, block coding, the "RC code" language,
on-device APK build and signing (no GitHub), AAB export and Play Store upload helper, Firebase/Supabase wizard.

## 3. The .rc project format (v1)
A .rc file is a ZIP container (just renamed). Contents:
- rc.json: {"format":"rc-project","formatVersion":1,"name":"<project>","createdWith":"RC App Studio","exportedAt":"<UTC ISO>","fileCount":N,"note":"..."}
- AI_CONTEXT.md: this file (so the AI reading the .rc understands everything).
- project/...: the real project files with their relative paths.
Importing a plain .zip also works (treated as project files; a single top-level folder is flattened).
If you are an AI asked to produce a .rc: create exactly this structure, zip it, name it <project>.rc. Keep project files under project/.
Optional per-project files: PROJECT_NOTES.md (goal, status, decisions, next steps) and rc-app.json (app name, packageName, versionName, versionCode, primaryColor, logo).

## 4. Rules for AI when generating projects
- Default target: Android app, Kotlin, Jetpack Compose, Gradle Kotlin DSL (AGP 8.5.x, Kotlin 2.0.x, minSdk 24, compileSdk 34). Java is also fine. Minecraft mods (Fabric/Forge/NeoForge/Quilt) are common.
- Return FULL file contents, correct relative paths, no "..." placeholders.
- Keep UI professional and consistent; dark theme by default; follow rc-app.json (colors, name, package, version).
- Never put API keys, tokens, or passwords into files. Use placeholders and tell the owner where to set them.
- When done, list what is untested and what the owner must do next. Suggest an update to PROJECT_NOTES.md.
- Follow Mojang brand rules: do not use "Minecraft" as the name of an app; "for Minecraft" as a tagline is fine.

## 5. Assets system (offline-first)
1. Online: download from official sources using the USER's internet. Show size in MB before each download (checkbox "don't show again").
2. Offline: if the user allowed device assets, search the folder they picked and copy the asset.
3. Otherwise: generate a small built-in version from code, and queue the real download for when the net is back.
Everything is stored in the app's private files folder, grouped by date (Today, Yesterday, older), and the user can delete/share/save it.
Never redistribute Mojang files inside the app; download them on the device from official sources.

## 6. Known projects
### MDE AI (Minecraft Development Environment)
- Goal: user writes a detailed prompt, picks loader (Fabric/Forge/NeoForge/Quilt/Paper) and any Minecraft version; the app produces a mod/plugin (.jar + source zip).
- Pipeline: prompt -> feature extraction -> plan -> templates -> code -> build -> compile-error fix loop -> .jar.
- No API keys inside the app. Local model packs (Small ~500MB, Medium ~1.5GB, Large ~3GB+) are optional downloads. Online AI goes through the owner's Firebase Cloud Function, which enforces limits.
- Backend: Firebase Auth + Firestore + Cloud Functions (Blaze). Rules: users cannot change their own status/limits. Ban = disable Auth account + revoke tokens; the app also listens live and shows a blocked screen.
- Admin panel = a Telegram bot (webhook on a Cloud Function, obeys only the owner's Telegram ID). Commands: /stats /user @name /ban /suspend /unban /unsuspend /limit @name N /all N /broadcast /find. Support: user messages arrive as "@username: message"; the owner replies with "@username message" or Telegram Reply.
- UI: splash shows the static logo; the animated logo loops ONLY while the AI is working, then returns to the static logo. Dark only, background #000216. Live activity panel (what the AI is doing). Download-size confirmation with "don't show again". Assets gallery by date. Multi-language UI.
- Branding: app name "MDE AI". Generated mods carry the user's name as author and "Powered by MDE AI"; the credit must not be removed by the AI.
- Optional later module: YouTube (OAuth, analysis, ideas, auto comment replies in the commenter's language, 24h video analysis). VidIQ has no public API, and the YouTube API cannot "heart" comments.
- Status: splash + chat demo project exists (project.zip). Next: login, live ban status, support chat, then AI Cloud Function.
### Other projects
(Add new projects here. Keep one short paragraph per project and update PROJECT_NOTES.md inside each project.)

## 7. How the owner builds an APK today
Repo root contains project.zip and .github/workflows/build.yml (unzip -> gradle assembleDebug -> upload artifact). RC App Studio's "GitHub push" uploads project.zip. Once on-device build exists this will not be needed.
