package com.mdeai.studio

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Fs {
    fun root(ctx: Context): File = File(ctx.filesDir, "projects").apply { mkdirs() }

    fun projects(ctx: Context): List<File> =
        root(ctx).listFiles()?.filter { it.isDirectory }?.sortedBy { it.name.lowercase() }
            ?: emptyList()

    fun uniqueDir(ctx: Context, base: String): File {
        val clean = base.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "project" }
        var d = File(root(ctx), clean)
        var i = 1
        while (d.exists()) {
            d = File(root(ctx), "$clean-$i")
            i++
        }
        return d
    }

    fun displayName(cr: ContentResolver, uri: Uri): String {
        cr.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return "project.zip"
    }

    /** Zip ko projects folder me kholta hai. Agar zip ke andar ek hi root folder ho to use hata deta hai. */
    fun importZip(ctx: Context, uri: Uri): File {
        val name = displayName(ctx.contentResolver, uri)
            .removeSuffix(".zip").removeSuffix(".ZIP")
        val dest = uniqueDir(ctx, name)
        val tmp = File(ctx.cacheDir, "imp_" + System.nanoTime()).apply { mkdirs() }
        try {
            val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("File khul nahi rahi")
            input.use { ins ->
                ZipInputStream(BufferedInputStream(ins)).use { zin ->
                    var e: ZipEntry? = zin.nextEntry
                    while (e != null) {
                        val out = File(tmp, e.name)
                        if (!out.canonicalPath.startsWith(tmp.canonicalPath + File.separator)) {
                            throw IOException("Unsafe zip entry: " + e.name)
                        }
                        if (e.isDirectory) {
                            out.mkdirs()
                        } else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { fo -> zin.copyTo(fo) }
                        }
                        zin.closeEntry()
                        e = zin.nextEntry
                    }
                }
            }
            val kids = tmp.listFiles() ?: emptyArray()
            val src = if (kids.size == 1 && kids[0].isDirectory) kids[0] else tmp
            if (!src.copyRecursively(dest, overwrite = true)) throw IOException("Copy fail")
        } finally {
            tmp.deleteRecursively()
        }
        return dest
    }

    fun zipTo(dir: File, out: OutputStream) {
        ZipOutputStream(BufferedOutputStream(out)).use { z ->
            dir.walkTopDown().filter { it.isFile }.forEach { f ->
                val rel = f.relativeTo(dir).path.replace(File.separatorChar, '/')
                z.putNextEntry(ZipEntry(rel))
                f.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
    }

    fun zipBytes(dir: File): ByteArray {
        val bos = ByteArrayOutputStream()
        zipTo(dir, bos)
        return bos.toByteArray()
    }

    /** Text file hai ya binary (image/video)? */
    fun isText(f: File): Boolean {
        if (f.length() > 1_000_000) return false
        val buf = ByteArray(4096)
        val n = f.inputStream().use { it.read(buf) }
        for (i in 0 until maxOf(n, 0)) {
            if (buf[i].toInt() == 0) return false
        }
        return true
    }

    /** dir ke andar name banata hai, par project ke bahar nahi jane deta. */
    fun safeChild(project: File, dir: File, name: String): File? {
        if (name.isBlank()) return null
        val f = File(dir, name)
        return if (f.canonicalPath.startsWith(project.canonicalPath + File.separator)) f else null
    }

    fun sizeText(f: File): String {
        val b = f.length()
        return when {
            b < 1024 -> "$b B"
            b < 1024 * 1024 -> "${b / 1024} KB"
            else -> "${b / (1024 * 1024)} MB"
        }
    }
}
