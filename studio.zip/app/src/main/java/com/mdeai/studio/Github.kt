package com.mdeai.studio

import android.content.Context
import android.util.Base64
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object Github {
    data class Cfg(val token: String, val owner: String, val repo: String, val branch: String)

    fun load(ctx: Context): Cfg {
        val p = ctx.getSharedPreferences("gh", Context.MODE_PRIVATE)
        return Cfg(
            p.getString("token", "") ?: "",
            p.getString("owner", "") ?: "",
            p.getString("repo", "") ?: "",
            p.getString("branch", "") ?: ""
        )
    }

    fun save(ctx: Context, c: Cfg) {
        ctx.getSharedPreferences("gh", Context.MODE_PRIVATE).edit()
            .putString("token", c.token)
            .putString("owner", c.owner)
            .putString("repo", c.repo)
            .putString("branch", c.branch)
            .apply()
    }

    private fun open(url: String, method: String, token: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "MDE-Studio")
        c.connectTimeout = 20000
        c.readTimeout = 90000
        return c
    }

    private fun errText(c: HttpURLConnection, code: Int): String {
        val t = try {
            c.errorStream?.bufferedReader()?.readText() ?: ""
        } catch (e: Exception) {
            ""
        }
        return "GitHub error $code: " + t.take(300)
    }

    /** Repo ke root me project.zip upload/update karta hai. Isse Actions ka build chal padta hai. */
    fun pushZip(cfg: Cfg, zip: ByteArray, message: String): String {
        if (zip.size > 50 * 1024 * 1024) throw IOException("Zip 50MB se bada hai")
        val base = "https://api.github.com/repos/${cfg.owner}/${cfg.repo}/contents/project.zip"
        val refQ = if (cfg.branch.isNotBlank()) "?ref=${cfg.branch}" else ""

        var sha: String? = null
        val g = open(base + refQ, "GET", cfg.token)
        val gc = g.responseCode
        if (gc == 200) {
            sha = JSONObject(g.inputStream.bufferedReader().readText()).optString("sha")
        } else if (gc != 404) {
            val err = errText(g, gc)
            g.disconnect()
            throw IOException(err)
        }
        g.disconnect()

        val body = JSONObject()
        body.put("message", message)
        body.put("content", Base64.encodeToString(zip, Base64.NO_WRAP))
        if (!sha.isNullOrEmpty()) body.put("sha", sha)
        if (cfg.branch.isNotBlank()) body.put("branch", cfg.branch)
        val bytes = body.toString().toByteArray()

        val p = open(base, "PUT", cfg.token)
        p.doOutput = true
        p.setRequestProperty("Content-Type", "application/json")
        p.setFixedLengthStreamingMode(bytes.size)
        p.outputStream.use { it.write(bytes) }
        val pc = p.responseCode
        if (pc != 200 && pc != 201) {
            val err = errText(p, pc)
            p.disconnect()
            throw IOException(err)
        }
        p.disconnect()
        return if (pc == 201) "Upload ho gaya. Ab Actions me build shuru hoga."
        else "Update ho gaya. Ab Actions me build shuru hoga."
    }
}
