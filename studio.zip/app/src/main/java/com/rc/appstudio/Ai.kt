package com.rc.appstudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Bring-your-own-key AI: user apni API key daalta hai, key sirf uske phone me rehti hai. */
object Ai {
    data class Cfg(val provider: String, val key: String, val model: String, val baseUrl: String)
    data class FileOut(val path: String, val content: String)
    data class Result(val notes: String, val files: List<FileOut>)

    private fun p(ctx: Context) = ctx.getSharedPreferences("ai", Context.MODE_PRIVATE)

    fun load(ctx: Context): Cfg = Cfg(
        p(ctx).getString("provider", "gemini") ?: "gemini",
        p(ctx).getString("key", "") ?: "",
        p(ctx).getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash",
        p(ctx).getString("base", "") ?: ""
    )

    fun save(ctx: Context, c: Cfg) {
        p(ctx).edit()
            .putString("provider", c.provider)
            .putString("key", c.key)
            .putString("model", c.model)
            .putString("base", c.baseUrl)
            .apply()
    }

    /** Presets. Model naam badalte rehte hain, isliye user edit kar sakta hai. */
    fun preset(name: String, key: String): Cfg = when (name) {
        "gemini" -> Cfg("gemini", key, "gemini-2.5-flash", "")
        "openai" -> Cfg("openai", key, "gpt-4o-mini", "https://api.openai.com/v1")
        "deepseek" -> Cfg("openai", key, "deepseek-chat", "https://api.deepseek.com/v1")
        "groq" -> Cfg("openai", key, "llama-3.3-70b-versatile", "https://api.groq.com/openai/v1")
        "openrouter" -> Cfg("openai", key, "openai/gpt-4o-mini", "https://openrouter.ai/api/v1")
        else -> Cfg("openai", key, "", "")
    }

    const val SYSTEM = "You are RC AI, the code and UI generator inside RC App Studio, a mobile IDE. " +
        "The owner works only from an Android phone. Reply with ONLY one valid JSON object, no markdown fences, in this exact shape: " +
        "{\"notes\": \"short plain-language summary of what you did and anything untested\", " +
        "\"files\": [{\"path\": \"relative/path/File.kt\", \"content\": \"full file content\"}]}. " +
        "Rules: paths are relative to the project root, never start with a slash, never contain '..'. " +
        "Always return the FULL content of every file you create or change. " +
        "Default target is an Android app in Kotlin with Jetpack Compose and Gradle Kotlin DSL, unless the request or the project says otherwise " +
        "(Fabric or Forge Minecraft mods in Java are also common). " +
        "If rc-app.json exists, respect its appName, packageName, versionName, versionCode and primaryColor. " +
        "Make the UI professional and consistent, with a dark theme unless asked otherwise. " +
        "Never invent API keys or secrets, and never put real secrets in files. " +
        "Be honest in notes: say what you could not verify or test."

    fun projectContext(project: File): String {
        val sb = StringBuilder()
        sb.append("PROJECT NAME: ").append(project.name).append("\nFILES:\n")
        val files = project.walkTopDown().filter { it.isFile }.toList()
        for (f in files.take(300)) {
            sb.append("- ").append(f.relativeTo(project).path).append(" (").append(f.length()).append(" B)\n")
        }
        var budget = 30000
        sb.append("\nCONTENTS (small text files):\n")
        for (f in files) {
            if (budget <= 0) break
            if (f.length() > 8000 || !Fs.isText(f)) continue
            val t = f.readText()
            sb.append("\n=== ").append(f.relativeTo(project).path).append(" ===\n").append(t).append("\n")
            budget -= t.length
        }
        return sb.toString()
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 180000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            for ((k, v) in headers) c.setRequestProperty(k, v)
            val bytes = body.toByteArray()
            c.setFixedLengthStreamingMode(bytes.size)
            c.outputStream.use { it.write(bytes) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.readText() ?: ""
            if (code !in 200..299) throw IOException("AI error $code: " + text.take(300))
            return text
        } finally {
            c.disconnect()
        }
    }

    fun call(cfg: Cfg, system: String, user: String): String {
        return if (cfg.provider == "gemini") callGemini(cfg, system, user) else callOpenAi(cfg, system, user)
    }

    private fun callGemini(cfg: Cfg, system: String, user: String): String {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/" + cfg.model.trim() + ":generateContent"
        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
            )
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", user)))
                )
            )
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val resp = post(url, mapOf("x-goog-api-key" to cfg.key.trim()), body.toString())
        return JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }

    private fun callOpenAi(cfg: Cfg, system: String, user: String): String {
        val url = cfg.baseUrl.trim().trimEnd('/') + "/chat/completions"
        val msgs = JSONArray()
            .put(JSONObject().put("role", "system").put("content", system))
            .put(JSONObject().put("role", "user").put("content", user))
        val body = JSONObject().put("model", cfg.model.trim()).put("messages", msgs)
        val resp = post(url, mapOf("Authorization" to "Bearer " + cfg.key.trim()), body.toString())
        return JSONObject(resp).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    fun parse(raw: String): Result {
        val t = raw.trim()
        val s = t.indexOf('{')
        val e = t.lastIndexOf('}')
        if (s < 0 || e <= s) throw IOException("AI ne JSON nahi diya")
        val o = JSONObject(t.substring(s, e + 1))
        val arr = o.optJSONArray("files") ?: JSONArray()
        val files = ArrayList<FileOut>()
        for (i in 0 until arr.length()) {
            val f = arr.getJSONObject(i)
            files.add(FileOut(f.getString("path"), f.getString("content")))
        }
        return Result(o.optString("notes"), files)
    }
}
