package com.rc.appstudio

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class AiStep(val text: String, val done: Boolean)

@Composable
fun ColumnScope.AiTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val projects = remember { Fs.projects(ctx) }
    var selected by remember { mutableStateOf(projects.firstOrNull()) }
    var menu by remember { mutableStateOf(false) }
    var cfg by remember { mutableStateOf(Ai.load(ctx)) }
    var showSetup by remember { mutableStateOf(cfg.key.isBlank()) }
    var prompt by remember { mutableStateOf("") }
    val steps = remember { mutableStateListOf<AiStep>() }
    var working by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<Ai.Result?>(null) }

    val t = rememberInfiniteTransition(label = "pulse")
    val pulse by t.animateFloat(
        1f, 1.12f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "s"
    )

    fun markDone() {
        if (steps.isNotEmpty()) steps[steps.lastIndex] = steps[steps.lastIndex].copy(done = true)
    }

    fun run() {
        val p = selected
        if (p == null) {
            toast(ctx, "Pehle project chuno ya banao")
            return
        }
        if (cfg.key.isBlank()) {
            showSetup = true
            toast(ctx, "Pehle AI key daalo")
            return
        }
        if (prompt.isBlank() || working) return
        working = true
        result = null
        steps.clear()
        scope.launch {
            try {
                steps.add(AiStep("Project padh raha hoon", false))
                val context = withContext(Dispatchers.IO) { Ai.projectContext(p) }
                markDone()
                steps.add(AiStep("AI (" + cfg.provider + " / " + cfg.model + ") ko bhej raha hoon", false))
                val raw = withContext(Dispatchers.IO) {
                    Ai.call(cfg, Ai.SYSTEM, context + "\n\nREQUEST:\n" + prompt)
                }
                markDone()
                steps.add(AiStep("Jawab samajh raha hoon", false))
                val res = Ai.parse(raw)
                markDone()
                steps.add(AiStep("Taiyar: " + res.files.size + " files. Neeche dekho aur Apply karo", true))
                result = res
            } catch (e: Exception) {
                steps.add(AiStep("Fail: " + e.message, false))
            }
            working = false
        }
    }

    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        // live activity panel
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp)
                .background(RcCard, RoundedCornerShape(12.dp)).padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Image(
                painterResource(R.drawable.rc_logo), null,
                Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)).graphicsLayer {
                    scaleX = if (working) pulse else 1f
                    scaleY = if (working) pulse else 1f
                }
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text(if (working) "Kaam kar raha hoon..." else "Taiyar", color = Color.White, fontWeight = FontWeight.Bold)
                if (steps.isEmpty()) Text("Yahan live dikhega ki AI kya kar raha hai.", color = RcMuted, fontSize = 12.sp)
                steps.forEach {
                    Text(
                        (if (it.done) "✓ " else "… ") + it.text,
                        color = if (it.done) RcMuted else Color.White, fontSize = 12.sp
                    )
                }
            }
        }

        // project chunav
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Project: ", color = RcMuted)
            Box {
                TextButton(onClick = { menu = true }) { Text(selected?.name ?: "chuno") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    projects.forEach { p ->
                        DropdownMenuItem(text = { Text(p.name) }, onClick = {
                            selected = p
                            menu = false
                        })
                    }
                }
            }
            TextButton(onClick = { showSetup = !showSetup }) { Text("AI setup") }
        }

        if (showSetup) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("gemini", "openai", "deepseek", "groq", "openrouter").forEach { n ->
                    MdeButton(n, { cfg = Ai.preset(n, cfg.key) })
                }
            }
            OutlinedTextField(
                value = cfg.key, onValueChange = { cfg = cfg.copy(key = it) }, singleLine = true,
                label = { Text("API key") }, visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = cfg.model, onValueChange = { cfg = cfg.copy(model = it) }, singleLine = true,
                label = { Text("Model (naam badalte rehte hain, edit kar sakte ho)") },
                modifier = Modifier.fillMaxWidth()
            )
            if (cfg.provider != "gemini") {
                OutlinedTextField(
                    value = cfg.baseUrl, onValueChange = { cfg = cfg.copy(baseUrl = it) }, singleLine = true,
                    label = { Text("Base URL") }, modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.height(6.dp))
            MdeButton("AI setup save karo", {
                Ai.save(ctx, cfg)
                showSetup = false
                toast(ctx, "Save ho gaya")
            })
            Text(
                "Key sirf is phone me rehti hai. AI ko sirf tumhare project ki chhoti text files jaati hain.",
                color = RcMuted, fontSize = 11.sp
            )
        }

        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = prompt, onValueChange = { prompt = it },
            label = { Text("Kya banwana hai? (UI, code, sab likho)") },
            modifier = Modifier.fillMaxWidth().height(140.dp)
        )
        Spacer(Modifier.height(6.dp))
        MdeButton(if (working) "AI kaam kar raha hai..." else "AI se banao", { run() }, enabled = !working)

        val res = result
        if (res != null) {
            Spacer(Modifier.height(10.dp))
            Text("AI ka note", color = RcAccent, fontWeight = FontWeight.Bold)
            Text(res.notes.ifBlank { "(koi note nahi)" }, color = Color.White, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Text("Ye files likhi jayengi:", color = RcAccent, fontWeight = FontWeight.Bold)
            res.files.forEach { Text("• " + it.path, color = Color.White, fontSize = 12.sp) }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MdeButton("Apply karo", {
                    val p = selected
                    if (p != null) {
                        var n = 0
                        for (f in res.files) {
                            val target = Fs.safeChild(p, p, f.path)
                            if (target != null) {
                                try {
                                    target.parentFile?.mkdirs()
                                    target.writeText(f.content)
                                    n++
                                } catch (e: Exception) {
                                    toast(ctx, "Fail: " + f.path)
                                }
                            }
                        }
                        toast(ctx, "$n files likh di")
                        result = null
                    }
                })
                MdeButton("Cancel", { result = null })
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
