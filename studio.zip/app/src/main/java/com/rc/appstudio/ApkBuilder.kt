package com.rc.appstudio

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * On-device APK builder (bina GitHub, bina compiler):
 * bundled RC Runner APK + tumhara app.rc.json + assets -> manifest patch -> apksig se sign.
 */
object ApkBuilder {
    private val PKG = Regex("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$")

    private fun put(zo: ZipOutputStream, name: String, data: ByteArray) {
        zo.putNextEntry(ZipEntry(name))
        zo.write(data)
        zo.closeEntry()
    }

    private fun iconBytes(project: File, cfg: AppCfg.Cfg): ByteArray? {
        if (cfg.logo.isBlank()) return null
        val f = File(project, cfg.logo)
        if (!f.exists()) return null
        return try {
            val bmp = android.graphics.BitmapFactory.decodeFile(f.path) ?: return null
            val sc = android.graphics.Bitmap.createScaledBitmap(bmp, 192, 192, true)
            val bos = java.io.ByteArrayOutputStream()
            sc.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, bos)
            bos.toByteArray()
        } catch (e: Exception) {
            null
        }
    }

    fun build(ctx: Context, project: File, doc: RcDoc, log: (String) -> Unit): File {
        val cfg = AppCfg.load(project)
        if (!PKG.matches(cfg.packageName)) {
            throw IOException("Package galat hai: '" + cfg.packageName + "'. Aisa likho: com.naam.app (chhote akshar, ek dot zaroori)")
        }
        if (cfg.appName.isBlank()) throw IOException("App ka naam khali hai (App settings me daalo)")
        if (doc.screens.isEmpty()) throw IOException("App me koi screen nahi hai")

        log("Runner nikal raha hoon")
        val runner = File(ctx.cacheDir, "runner.apk")
        ctx.assets.open("runner.apk").use { i -> runner.outputStream().use { i.copyTo(it) } }

        log("Manifest aur assets taiyar kar raha hoon")
        val unsigned = File(ctx.cacheDir, "unsigned.apk")
        val logo = iconBytes(project, cfg)
        val names = HashSet<String>()
        ZipFile(runner).use { zf ->
            ZipOutputStream(BufferedOutputStream(FileOutputStream(unsigned))).use { zo ->
                val en = zf.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    val n = e.name
                    if (e.isDirectory) continue
                    if (n.startsWith("META-INF/") &&
                        (n.endsWith(".MF") || n.endsWith(".SF") || n.endsWith(".RSA") || n.endsWith(".DSA") || n.endsWith(".EC"))
                    ) continue
                    if (n == "assets/app.rc.json") continue
                    val raw = zf.getInputStream(e).use { it.readBytes() }
                    val data: ByteArray = when {
                        n == "AndroidManifest.xml" ->
                            Axml.patch(raw, cfg.packageName, cfg.appName, cfg.versionName, cfg.versionCode)
                        n.endsWith("/rc_icon.png") && logo != null -> logo
                        else -> raw
                    }
                    put(zo, n, data)
                    names.add(n)
                }
                put(zo, "assets/app.rc.json", RcJson.buildFinal(doc, cfg).toByteArray())
                val ad = File(project, "assets")
                if (ad.isDirectory) {
                    ad.walkTopDown().filter { it.isFile }.forEach { f ->
                        val rel = "assets/" + f.relativeTo(ad).path.replace(File.separatorChar, '/')
                        if (rel !in names && rel != "assets/app.rc.json") put(zo, rel, f.readBytes())
                    }
                }
            }
        }

        log("Sign kar raha hoon")
        val safe = cfg.appName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val out = File(Fs.downloads(ctx), safe + "-" + cfg.versionName.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".apk")
        Keys.sign(ctx, unsigned, out)
        unsigned.delete()
        runner.delete()
        log("Taiyar: " + out.name)
        return out
    }

    fun install(ctx: Context, apk: File) {
        try {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", apk)
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, "application/vnd.android.package-archive")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            toast(ctx, "Install nahi khula: " + e.message)
        }
    }
}
