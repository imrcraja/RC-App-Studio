package com.rc.appstudio

import org.json.JSONObject
import java.io.File

/** Project ke andar rc-app.json: banne wale app ki settings (naam, package, version, color, logo). */
object AppCfg {
    data class Cfg(
        val appName: String,
        val packageName: String,
        val versionName: String,
        val versionCode: Int,
        val primaryColor: String,
        val logo: String
    )

    fun file(project: File) = File(project, "rc-app.json")

    fun load(project: File): Cfg {
        val f = file(project)
        if (f.exists()) {
            try {
                val o = JSONObject(f.readText())
                return Cfg(
                    o.optString("appName", project.name),
                    o.optString("packageName", "com.example.app"),
                    o.optString("versionName", "1.0"),
                    o.optInt("versionCode", 1),
                    o.optString("primaryColor", "#7C4DFF"),
                    o.optString("logo", "")
                )
            } catch (e: Exception) {
                // kharab file ho to default
            }
        }
        val pkg = "com.example." + project.name.lowercase().replace(Regex("[^a-z0-9]"), "")
        return Cfg(project.name, pkg, "1.0", 1, "#7C4DFF", "")
    }

    fun save(project: File, c: Cfg) {
        val o = JSONObject()
        o.put("appName", c.appName)
        o.put("packageName", c.packageName)
        o.put("versionName", c.versionName)
        o.put("versionCode", c.versionCode)
        o.put("primaryColor", c.primaryColor)
        o.put("logo", c.logo)
        file(project).writeText(o.toString(2))
    }
}
