package com.rc.appstudio

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Assets system (offline-first logic):
 *  1. Net ho  -> user ke internet se download (size dikhake).
 *  2. Net nahi -> agar user ne device-assets allow kiye hain to chune hue folder se dhundho.
 *  3. Wo bhi nahi -> code se built-in version banao aur net aane par download ke liye pending me daalo.
 * Sab kuch app ke apne folder me, date ke hisaab se save hota hai (gallery jaisa).
 */
object Assets {
    data class Entry(
        val id: String,
        val title: String,
        val fileName: String,
        val url: String?,
        val builtin: String?
    )

    data class Rec(val path: String, val title: String, val source: String, val at: Long)
    data class Pending(val url: String, val fileName: String, val title: String, val builtin: String?)

    val catalog = listOf(
        Entry(
            "mc_versions", "Minecraft versions list (Mojang)", "minecraft_versions.json",
            "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json", "mc_versions"
        ),
        Entry(
            "fabric_game", "Fabric supported game versions", "fabric_game_versions.json",
            "https://meta.fabricmc.net/v2/versions/game", "fabric_game"
        ),
        Entry(
            "fabric_loader", "Fabric loader versions", "fabric_loader_versions.json",
            "https://meta.fabricmc.net/v2/versions/loader", "fabric_loader"
        ),
        Entry(
            "android_workflow", "GitHub Actions: Android APK workflow", "build-android.yml",
            null, "android_workflow"
        )
    )

    fun dir(ctx: Context): File = File(ctx.filesDir, "assets").apply { mkdirs() }
    private fun indexFile(ctx: Context) = File(dir(ctx), "index.json")

    fun isOnline(ctx: Context): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork
            val c = if (n == null) null else cm.getNetworkCapabilities(n)
            c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            false
        }
    }

    /* ---------- index (gallery ka record) ---------- */

    fun records(ctx: Context): List<Rec> {
        val f = indexFile(ctx)
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            val out = ArrayList<Rec>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val r = Rec(o.getString("path"), o.optString("title"), o.optString("source"), o.optLong("at"))
                if (File(dir(ctx), r.path).exists()) out.add(r)
            }
            out.sortedByDescending { it.at }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveRecords(ctx: Context, list: List<Rec>) {
        val arr = JSONArray()
        for (r in list) {
            val o = JSONObject()
            o.put("path", r.path)
            o.put("title", r.title)
            o.put("source", r.source)
            o.put("at", r.at)
            arr.put(o)
        }
        indexFile(ctx).writeText(arr.toString())
    }

    private fun register(ctx: Context, file: File, title: String, source: String) {
        val base = dir(ctx)
        val rel = file.relativeTo(base).path.replace(File.separatorChar, '/')
        val all = records(ctx).toMutableList()
        val iter = all.iterator()
        while (iter.hasNext()) {
            val r = iter.next()
            if (File(r.path).name == file.name && r.path != rel) {
                File(base, r.path).delete()
                iter.remove()
            }
        }
        all.removeAll { x -> x.path == rel }
        all.add(Rec(rel, title, source, System.currentTimeMillis()))
        saveRecords(ctx, all)
    }

    fun delete(ctx: Context, r: Rec) {
        File(dir(ctx), r.path).delete()
        saveRecords(ctx, records(ctx).filter { it.path != r.path })
    }

    private fun target(ctx: Context, fileName: String): File {
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val d = File(dir(ctx), day)
        d.mkdirs()
        return File(d, fileName.replace(Regex("[^A-Za-z0-9._-]"), "_"))
    }

    /* ---------- 1. online download ---------- */

    fun headSize(url: String): Long {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "HEAD"
            c.connectTimeout = 15000
            c.readTimeout = 15000
            c.setRequestProperty("User-Agent", "RC-App-Studio")
            c.connect()
            return c.contentLengthLong
        } finally {
            c.disconnect()
        }
    }

    fun download(ctx: Context, url: String, fileName: String, title: String): File {
        val out = target(ctx, fileName)
        val part = File(out.parentFile, out.name + ".part")
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 20000
            c.readTimeout = 60000
            c.setRequestProperty("User-Agent", "RC-App-Studio")
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            c.inputStream.use { ins -> part.outputStream().use { ins.copyTo(it) } }
            if (out.exists()) out.delete()
            if (!part.renameTo(out)) throw IOException("Rename fail")
        } finally {
            c.disconnect()
            part.delete()
        }
        register(ctx, out, title, "online")
        removePending(ctx, fileName)
        return out
    }

    /* ---------- 2. user ke mobile me maujud asset ---------- */

    private fun search(d: DocumentFile, name: String, depth: Int): DocumentFile? {
        for (f in d.listFiles()) {
            if (f.isFile && f.name == name) return f
            if (f.isDirectory && depth > 0) {
                val r = search(f, name, depth - 1)
                if (r != null) return r
            }
        }
        return null
    }

    fun copyFromDevice(ctx: Context, fileName: String, title: String): Boolean {
        val treeStr = Prefs.tree(ctx) ?: return false
        val root = DocumentFile.fromTreeUri(ctx, Uri.parse(treeStr)) ?: return false
        val found = search(root, fileName, 3) ?: return false
        val out = target(ctx, fileName)
        val ins = ctx.contentResolver.openInputStream(found.uri) ?: return false
        ins.use { i -> out.outputStream().use { i.copyTo(it) } }
        register(ctx, out, title, "device")
        return true
    }

    /* ---------- 3. code se built-in version ---------- */

    fun fromBuiltin(ctx: Context, id: String, fileName: String, title: String): File {
        val out = target(ctx, fileName)
        out.writeText(Builtin.text(id))
        register(ctx, out, title, "built-in")
        return out
    }

    /* ---------- pending (net aane par download) ---------- */

    fun pending(ctx: Context): List<Pending> {
        return try {
            val arr = JSONArray(Prefs.pending(ctx))
            val out = ArrayList<Pending>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Pending(
                        o.getString("url"), o.getString("fileName"), o.optString("title"),
                        if (o.has("builtin")) o.optString("builtin") else null
                    )
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun savePending(ctx: Context, list: List<Pending>) {
        val arr = JSONArray()
        for (p in list) {
            val o = JSONObject()
            o.put("url", p.url)
            o.put("fileName", p.fileName)
            o.put("title", p.title)
            if (p.builtin != null) o.put("builtin", p.builtin)
            arr.put(o)
        }
        Prefs.setPending(ctx, arr.toString())
    }

    fun addPending(ctx: Context, p: Pending) {
        savePending(ctx, pending(ctx).filter { it.fileName != p.fileName } + p)
    }

    fun removePending(ctx: Context, fileName: String) {
        savePending(ctx, pending(ctx).filter { it.fileName != fileName })
    }
}

/** Net na ho tab code se banne wale chhote versions. */
object Builtin {
    private const val VERSIONS =
        "\"1.21.1\",\"1.21\",\"1.20.6\",\"1.20.4\",\"1.20.2\",\"1.20.1\",\"1.19.4\",\"1.19.2\",\"1.18.2\",\"1.16.5\",\"1.12.2\""

    fun text(id: String): String = when (id) {
        "mc_versions" ->
            "{\"note\":\"built-in offline list, net aane par asli list download hogi\",\"versions\":[" + VERSIONS + "]}"
        "fabric_game" ->
            "{\"note\":\"built-in offline list, net aane par asli list download hogi\",\"versions\":[" + VERSIONS + "]}"
        "fabric_loader" ->
            "{\"note\":\"built-in placeholder, loader versions net aane par download honge\"}"
        "android_workflow" -> ANDROID_WORKFLOW
        else -> ""
    }

    private val ANDROID_WORKFLOW = """
name: Build APK
on:
  workflow_dispatch:
  push:
    paths: ['project.zip']
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Unzip project
        run: unzip -q project.zip -d work
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: 8.9
      - name: Build
        working-directory: work
        run: gradle assembleDebug --no-daemon
      - uses: actions/upload-artifact@v4
        with:
          name: APK
          path: work/app/build/outputs/apk/debug/*.apk
""".trimStart()
}
