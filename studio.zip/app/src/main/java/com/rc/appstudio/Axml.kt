package com.rc.appstudio

import java.io.ByteArrayOutputStream
import java.io.IOException

/**
 * Binary AndroidManifest.xml (AXML) patcher.
 * Runner APK ke manifest me package, label, versionName ke strings aur versionCode badalta hai.
 * Sirf string pool dobara likhta hai; baaki chunks jaise ke taise rehte hain.
 */
object Axml {
    private const val CH_XML = 0x0003
    private const val CH_STRPOOL = 0x0001
    private const val CH_START_ELEM = 0x0102

    private fun u16(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)

    private fun u32(b: ByteArray, o: Int): Int = u16(b, o) or (u16(b, o + 2) shl 16)

    private fun put16(o: ByteArrayOutputStream, v: Int) {
        o.write(v and 0xFF)
        o.write((v shr 8) and 0xFF)
    }

    private fun put32(o: ByteArrayOutputStream, v: Int) {
        put16(o, v and 0xFFFF)
        put16(o, (v ushr 16) and 0xFFFF)
    }

    private class Pool(val utf8: Boolean, val flags: Int, val strings: MutableList<String>)

    private fun readPool(b: ByteArray, start: Int): Pool {
        val hdr = u16(b, start + 2)
        val count = u32(b, start + 8)
        val styleCount = u32(b, start + 12)
        val flags = u32(b, start + 16)
        val strStart = u32(b, start + 20)
        if (styleCount != 0) throw IOException("Manifest me style spans hain, patch nahi ho sakta")
        val utf8 = (flags and 0x100) != 0
        val list = ArrayList<String>(count)
        for (i in 0 until count) {
            val off = u32(b, start + hdr + 4 * i)
            var p = start + strStart + off
            if (utf8) {
                // char length
                p += if ((b[p].toInt() and 0x80) != 0) 2 else 1
                // byte length
                var bl = b[p].toInt() and 0xFF
                if ((bl and 0x80) != 0) {
                    bl = ((bl and 0x7F) shl 8) or (b[p + 1].toInt() and 0xFF)
                    p += 2
                } else {
                    p += 1
                }
                list.add(String(b, p, bl, Charsets.UTF_8))
            } else {
                var l = u16(b, p)
                p += 2
                if ((l and 0x8000) != 0) {
                    l = ((l and 0x7FFF) shl 16) or u16(b, p)
                    p += 2
                }
                list.add(String(b, p, l * 2, Charsets.UTF_16LE))
            }
        }
        return Pool(utf8, flags, list)
    }

    private fun writePool(p: Pool): ByteArray {
        val data = ByteArrayOutputStream()
        val offs = IntArray(p.strings.size)
        for (i in p.strings.indices) {
            offs[i] = data.size()
            val s = p.strings[i]
            if (p.utf8) {
                val bytes = s.toByteArray(Charsets.UTF_8)
                val cl = s.length
                if (cl > 0x7F) {
                    data.write(0x80 or (cl shr 8))
                    data.write(cl and 0xFF)
                } else {
                    data.write(cl)
                }
                val bl = bytes.size
                if (bl > 0x7F) {
                    data.write(0x80 or (bl shr 8))
                    data.write(bl and 0xFF)
                } else {
                    data.write(bl)
                }
                data.write(bytes)
                data.write(0)
            } else {
                val l = s.length
                if (l > 0x7FFF) {
                    put16(data, 0x8000 or (l shr 16))
                    put16(data, l and 0xFFFF)
                } else {
                    put16(data, l)
                }
                data.write(s.toByteArray(Charsets.UTF_16LE))
                put16(data, 0)
            }
        }
        while (data.size() % 4 != 0) data.write(0)
        val n = p.strings.size
        val hdr = 28
        val strStart = hdr + 4 * n
        val size = strStart + data.size()
        val out = ByteArrayOutputStream()
        put16(out, CH_STRPOOL)
        put16(out, hdr)
        put32(out, size)
        put32(out, n)
        put32(out, 0)
        put32(out, p.flags and 0x1.inv()) // sorted flag hata do
        put32(out, strStart)
        put32(out, 0)
        for (o in offs) put32(out, o)
        out.write(data.toByteArray())
        return out.toByteArray()
    }

    fun patch(src: ByteArray, pkg: String, label: String, versionName: String, versionCode: Int): ByteArray {
        if (u16(src, 0) != CH_XML) throw IOException("Manifest binary XML nahi hai")
        val fileHdr = u16(src, 2)
        val poolPos = fileHdr
        if (u16(src, poolPos) != CH_STRPOOL) throw IOException("String pool pehle nahi mila")
        val poolSize = u32(src, poolPos + 4)
        val pool = readPool(src, poolPos)
        val body = src.copyOf()
        var p = poolPos + poolSize
        var patchedCode = false
        val edits = HashMap<Int, String>()

        while (p + 8 <= body.size) {
            val type = u16(body, p)
            val size = u32(body, p + 4)
            if (size <= 0) break
            if (type == CH_START_ELEM) {
                val elem = pool.strings[u32(body, p + 20)]
                val attrStart = u16(body, p + 24)
                val attrSize = u16(body, p + 26)
                val attrCount = u16(body, p + 28)
                val base = p + 16 + attrStart
                for (i in 0 until attrCount) {
                    val a = base + i * attrSize
                    val name = pool.strings[u32(body, a + 4)]
                    val dataType = body[a + 15].toInt() and 0xFF
                    val data = u32(body, a + 16)
                    if (elem == "manifest") {
                        if (name == "package" && dataType == 0x03) edits[data] = pkg
                        if (name == "versionName" && dataType == 0x03) edits[data] = versionName
                        if (name == "versionCode" && dataType == 0x10) {
                            body[a + 16] = (versionCode and 0xFF).toByte()
                            body[a + 17] = ((versionCode shr 8) and 0xFF).toByte()
                            body[a + 18] = ((versionCode shr 16) and 0xFF).toByte()
                            body[a + 19] = ((versionCode shr 24) and 0xFF).toByte()
                            patchedCode = true
                        }
                    }
                    if (elem == "application" && name == "label" && dataType == 0x03) edits[data] = label
                }
            }
            p += size
        }
        if (edits.isEmpty()) throw IOException("Manifest me package/label nahi mile (runner galat hai)")
        if (!patchedCode) throw IOException("versionCode nahi mila")
        for ((idx, v) in edits) pool.strings[idx] = v

        val newPool = writePool(pool)
        val out = ByteArrayOutputStream()
        put16(out, CH_XML)
        put16(out, fileHdr)
        put32(out, 0) // size baad me
        out.write(newPool)
        val restStart = poolPos + poolSize
        out.write(body, restStart, body.size - restStart)
        val res = out.toByteArray()
        val total = res.size
        res[4] = (total and 0xFF).toByte()
        res[5] = ((total shr 8) and 0xFF).toByte()
        res[6] = ((total shr 16) and 0xFF).toByte()
        res[7] = ((total shr 24) and 0xFF).toByte()
        return res
    }
}
