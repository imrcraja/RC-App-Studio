package com.rc.appstudio

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Cloud backup (abhi Supabase Storage). mode: local | cloud | both */
object Cloud {
    data class Cfg(val mode: String, val url: String, val key: String, val bucket: String)

    private fun p(ctx: Context) = ctx.getSharedPreferences("cloud", Context.MODE_PRIVATE)

    fun load(ctx: Context): Cfg = Cfg(
        p(ctx).getString("mode", "local") ?: "local",
        p(ctx).getString("url", "") ?: "",
        p(ctx).getString("key", "") ?: "",
        p(ctx).getString("bucket", "") ?: ""
    )

    fun save(ctx: Context, c: Cfg) {
        p(ctx).edit()
            .putString("mode", c.mode)
            .putString("url", c.url)
            .putString("key", c.key)
            .putString("bucket", c.bucket)
            .apply()
    }

    fun ready(c: Cfg): Boolean =
        c.mode != "local" && c.url.isNotBlank() && c.key.isNotBlank() && c.bucket.isNotBlank()

    fun upload(c: Cfg, file: File, remoteName: String) {
        val name = URLEncoder.encode(remoteName, "UTF-8").replace("+", "%20")
        val u = c.url.trim().trimEnd('/') + "/storage/v1/object/" + c.bucket.trim() + "/" + name
        val con = URL(u).openConnection() as HttpURLConnection
        try {
            con.requestMethod = "POST"
            con.doOutput = true
            con.connectTimeout = 20000
            con.readTimeout = 120000
            con.setRequestProperty("Authorization", "Bearer " + c.key.trim())
            con.setRequestProperty("apikey", c.key.trim())
            con.setRequestProperty("x-upsert", "true")
            con.setRequestProperty("Content-Type", "application/octet-stream")
            con.setFixedLengthStreamingMode(file.length())
            file.inputStream().use { ins -> con.outputStream.use { ins.copyTo(it) } }
            val code = con.responseCode
            if (code !in 200..299) {
                val t = try {
                    con.errorStream?.bufferedReader()?.readText() ?: ""
                } catch (e: Exception) {
                    ""
                }
                throw IOException("Cloud error $code: " + t.take(300))
            }
        } finally {
            con.disconnect()
        }
    }
}
