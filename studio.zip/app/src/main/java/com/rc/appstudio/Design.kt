package com.rc.appstudio

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** RC app ka model: screens -> nodes (UI) + scripts (RC code). app.rc.json me save hota hai. */
class Node(var type: String, var id: String) {
    val props = LinkedHashMap<String, String>()
    val kids = ArrayList<Node>()

    fun isContainer(): Boolean = type == "row" || type == "column"

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("type", type)
        o.put("id", id)
        val p = JSONObject()
        for ((k, v) in props) if (v.isNotEmpty()) p.put(k, v)
        o.put("props", p)
        if (kids.isNotEmpty()) {
            val a = JSONArray()
            for (k in kids) a.put(k.toJson())
            o.put("kids", a)
        }
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Node {
            val n = Node(o.optString("type", "column"), o.optString("id"))
            val p = o.optJSONObject("props")
            if (p != null) {
                val it = p.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    n.props[k] = p.optString(k)
                }
            }
            val ks = o.optJSONArray("kids")
            if (ks != null) {
                for (i in 0 until ks.length()) n.kids.add(fromJson(ks.getJSONObject(i)))
            }
            return n
        }
    }
}

class ScreenDef(var id: String, var title: String, var bg: String, val root: Node)

class RcDoc {
    val screens = ArrayList<ScreenDef>()
    val scripts = LinkedHashMap<String, String>()
    var start = "main"
}

object RcJson {
    fun file(project: File) = File(project, "app.rc.json")

    fun newRoot(): Node {
        val r = Node("column", "root")
        r.props["w"] = "match"
        r.props["h"] = "match"
        r.props["padding"] = "16"
        return r
    }

    fun template(): RcDoc {
        val d = RcDoc()
        val root = newRoot()
        val t = Node("text", "title")
        t.props["text"] = "Namaste RC App"
        t.props["size"] = "24"
        t.props["bold"] = "true"
        t.props["margin"] = "8"
        val i = Node("input", "name")
        i.props["hint"] = "Apna naam likho"
        i.props["margin"] = "8"
        val b = Node("button", "b1")
        b.props["text"] = "Bhejo"
        b.props["onClick"] = "hello"
        b.props["margin"] = "8"
        val g = Node("text", "greeting")
        g.props["text"] = ""
        g.props["size"] = "18"
        g.props["color"] = "#29B6F6"
        g.props["margin"] = "8"
        root.kids.addAll(listOf(t, i, b, g))
        d.screens.add(ScreenDef("main", "Home", "#000216", root))
        d.scripts["hello"] = "set n = get name\nif n == \"\"\ntoast \"Pehle naam likho\"\nelse\ntext greeting = \"Namaste \" + n\nend"
        return d
    }

    fun load(project: File): RcDoc {
        val f = file(project)
        if (!f.exists()) return template()
        return try {
            val o = JSONObject(f.readText())
            val d = RcDoc()
            d.start = o.optString("start", "main")
            val arr = o.optJSONArray("screens") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val s = arr.getJSONObject(i)
                val r = s.optJSONObject("root")
                d.screens.add(
                    ScreenDef(
                        s.optString("id"), s.optString("title"), s.optString("bg", "#000216"),
                        if (r != null) Node.fromJson(r) else newRoot()
                    )
                )
            }
            val sc = o.optJSONObject("scripts")
            if (sc != null) {
                val it = sc.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    d.scripts[k] = sc.optString(k)
                }
            }
            if (d.screens.isEmpty()) template() else d
        } catch (e: Exception) {
            template()
        }
    }

    fun toJson(doc: RcDoc): JSONObject {
        val o = JSONObject()
        o.put("start", doc.start)
        val arr = JSONArray()
        for (s in doc.screens) {
            val so = JSONObject()
            so.put("id", s.id)
            so.put("title", s.title)
            so.put("bg", s.bg)
            so.put("root", s.root.toJson())
            arr.put(so)
        }
        o.put("screens", arr)
        val sc = JSONObject()
        for ((k, v) in doc.scripts) sc.put(k, v)
        o.put("scripts", sc)
        return o
    }

    fun save(project: File, doc: RcDoc) {
        file(project).writeText(toJson(doc).toString(2))
    }

    /** Runner ke liye final JSON (app info ke saath). */
    fun buildFinal(doc: RcDoc, cfg: AppCfg.Cfg): String {
        val o = toJson(doc)
        val app = JSONObject()
        app.put("name", cfg.appName)
        app.put("primary", cfg.primaryColor)
        o.put("app", app)
        if (doc.screens.none { it.id == doc.start }) o.put("start", doc.screens[0].id)
        return o.toString()
    }

    fun allNodes(doc: RcDoc): List<Node> {
        val out = ArrayList<Node>()
        fun walk(n: Node) {
            out.add(n)
            for (k in n.kids) walk(k)
        }
        for (s in doc.screens) walk(s.root)
        return out
    }

    fun uniqueId(doc: RcDoc, base: String): String {
        val used = allNodes(doc).map { it.id }.toSet()
        var i = 1
        while ((base + i) in used) i++
        return base + i
    }
}
