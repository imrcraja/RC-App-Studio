package com.rc.appstudio

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rc.lang.RcLang
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

fun colorOr(s: String?, def: Color): Color = if (s.isNullOrBlank()) def else parseColor(s)

fun parentOf(root: Node, target: Node): Node? {
    for (k in root.kids) {
        if (k === target) return root
        val r = parentOf(k, target)
        if (r != null) return r
    }
    return null
}

fun moveNode(parent: Node, n: Node, d: Int): Boolean {
    val i = parent.kids.indexOf(n)
    val j = i + d
    if (i < 0 || j < 0 || j >= parent.kids.size) return false
    parent.kids.removeAt(i)
    parent.kids.add(j, n)
    return true
}

class TreeRow(val node: Node, val parent: Node?, val depth: Int)

fun flatten(n: Node, parent: Node?, depth: Int, out: MutableList<TreeRow>) {
    out.add(TreeRow(n, parent, depth))
    for (k in n.kids) flatten(k, n, depth + 1, out)
}

@Composable
fun DesignScreen(project: File, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val doc = remember { RcJson.load(project) }
    var rev by remember { mutableIntStateOf(0) }
    var screenIdx by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Node?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    var dirty by remember { mutableStateOf(false) }
    var askExit by remember { mutableStateOf(false) }
    var showNewScreen by remember { mutableStateOf(false) }
    var screenMenu by remember { mutableStateOf(false) }
    var building by remember { mutableStateOf(false) }
    var buildLog by remember { mutableStateOf(listOf<String>()) }
    var built by remember { mutableStateOf<File?>(null) }
    var buildError by remember { mutableStateOf<String?>(null) }
    val actions = rememberFileActions()

    val r = rev
    val idx = screenIdx.coerceIn(0, doc.screens.size - 1)
    val screen = doc.screens[idx]

    fun touch() {
        rev++
        dirty = true
    }

    fun save() {
        try {
            RcJson.save(project, doc)
            dirty = false
            toast(ctx, "Save ho gaya")
        } catch (e: Exception) {
            toast(ctx, "Save fail: " + e.message)
        }
    }

    fun addNode(type: String) {
        val n = Node(type, RcJson.uniqueId(doc, type))
        when (type) {
            "text" -> {
                n.props["text"] = "Text"
                n.props["size"] = "16"
                n.props["margin"] = "8"
            }
            "button" -> {
                n.props["text"] = "Button"
                n.props["margin"] = "8"
            }
            "input" -> {
                n.props["hint"] = "Hint"
                n.props["margin"] = "8"
            }
            "image" -> {
                n.props["src"] = "logo.png"
                n.props["w"] = "96"
                n.props["h"] = "96"
            }
            "row", "column" -> {
                n.props["w"] = "match"
                n.props["padding"] = "8"
            }
            "spacer" -> n.props["h"] = "16"
        }
        val sel = selected
        val target: Node = when {
            sel != null && sel.isContainer() -> sel
            sel != null -> parentOf(screen.root, sel) ?: screen.root
            else -> screen.root
        }
        target.kids.add(n)
        selected = n
        touch()
    }

    fun build() {
        if (building) return
        for ((k, v) in doc.scripts) {
            val e = RcLang.check(v)
            if (e != null) {
                toast(ctx, "Script '$k' me galti: $e")
                tab = 3
                return
            }
        }
        try {
            RcJson.save(project, doc)
            dirty = false
        } catch (e: Exception) {
            toast(ctx, "Save fail: " + e.message)
            return
        }
        building = true
        buildLog = emptyList()
        built = null
        buildError = null
        scope.launch {
            try {
                val f = withContext(Dispatchers.IO) {
                    ApkBuilder.build(ctx, project, doc) { m ->
                        scope.launch(Dispatchers.Main) { buildLog = buildLog + m }
                    }
                }
                built = f
            } catch (e: Throwable) {
                buildError = e.message ?: e.toString()
            }
        }
    }

    BackHandler { if (dirty) askExit = true else onClose() }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { if (dirty) askExit = true else onClose() }) { Text("←", fontSize = 20.sp) }
            Text(
                "Design" + (if (dirty) " •" else ""), color = Color.White,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
            )
            MdeButton("Save", { save() })
            Spacer(Modifier.width(6.dp))
            MdeButton("Build APK", { build() })
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.horizontalScroll(rememberScrollState())) {
            Text("Screen:", color = RcMuted, fontSize = 12.sp)
            Box {
                TextButton(onClick = { screenMenu = true }) { Text(screen.id) }
                DropdownMenu(expanded = screenMenu, onDismissRequest = { screenMenu = false }) {
                    doc.screens.forEachIndexed { i, s ->
                        DropdownMenuItem(text = { Text(s.id) }, onClick = {
                            screenIdx = i
                            selected = null
                            screenMenu = false
                        })
                    }
                }
            }
            TextButton(onClick = { showNewScreen = true }) { Text("+ Screen") }
            if (doc.screens.size > 1) {
                TextButton(onClick = {
                    doc.screens.removeAt(idx)
                    screenIdx = 0
                    selected = null
                    touch()
                }) { Text("Screen delete") }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("text", "button", "input", "image", "row", "column", "spacer").forEach { t ->
                MdeButton("+ $t", { addNode(t) })
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            listOf("Preview", "Tree", "Props", "Scripts").forEachIndexed { i, t ->
                TextButton(onClick = { tab = i }) {
                    Text(
                        t, color = if (tab == i) RcAccent else RcMuted,
                        fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> {
                    val bg = parseColor(screen.bg)
                    val lum = (bg.red * 299 + bg.green * 587 + bg.blue * 114) / 1000f
                    Column(Modifier.fillMaxSize().background(bg).verticalScroll(rememberScrollState())) {
                        PreviewNode(screen.root, selected, { selected = it }, if (lum < 0.5f) Color.White else Color.Black, r)
                    }
                }
                1 -> TreeTab(screen.root, selected, { selected = it; touch() }, { touch() },
                    onDelete = { n ->
                        val p = parentOf(screen.root, n)
                        if (p != null) {
                            p.kids.remove(n)
                            if (selected === n) selected = null
                            touch()
                        }
                    })
                2 -> PropsTab(doc, screen, selected, { dirty = true }, onDelete = { n ->
                    val p = parentOf(screen.root, n)
                    if (p != null) {
                        p.kids.remove(n)
                        selected = null
                        touch()
                    }
                })
                else -> ScriptsTab(doc, { dirty = true }, { touch() })
            }
        }
    }

    if (showNewScreen) {
        InputDialog("Nayi screen ka id (jaise: settings)", "", onOk = { n ->
            val id = n.replace(Regex("[^A-Za-z0-9_]"), "")
            if (id.isNotEmpty() && doc.screens.none { it.id == id }) {
                doc.screens.add(ScreenDef(id, id, "#000216", RcJson.newRoot()))
                screenIdx = doc.screens.size - 1
                selected = null
                touch()
            } else {
                toast(ctx, "Id khali ya pehle se hai")
            }
            showNewScreen = false
        }, onCancel = { showNewScreen = false })
    }
    if (askExit) {
        AlertDialog(
            onDismissRequest = { askExit = false },
            title = { Text("Save karein?") },
            text = { Text("Badlav save nahi hue hain.") },
            confirmButton = {
                TextButton(onClick = {
                    save()
                    askExit = false
                    onClose()
                }) { Text("Save") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        askExit = false
                        onClose()
                    }) { Text("Chhodo") }
                    TextButton(onClick = { askExit = false }) { Text("Cancel") }
                }
            }
        )
    }
    if (building) {
        val f = built
        val err = buildError
        AlertDialog(
            onDismissRequest = { if (f != null || err != null) building = false },
            title = { Text(if (f != null) "APK taiyar" else if (err != null) "Build fail" else "Build ho raha hai...") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    buildLog.forEach { Text("✓ $it", color = RcMuted, fontSize = 12.sp) }
                    if (err != null) Text(err, color = Color(0xFFFF7043), fontSize = 12.sp)
                    if (f != null) Text("Downloads me save: " + f.name, color = Color.White, fontSize = 13.sp)
                }
            },
            confirmButton = {
                if (f != null) TextButton(onClick = { ApkBuilder.install(ctx, f) }) { Text("Install") }
            },
            dismissButton = {
                Row {
                    if (f != null) {
                        TextButton(onClick = { actions.share(f) }) { Text("Share") }
                        TextButton(onClick = { actions.save(f) }) { Text("Save to…") }
                    }
                    TextButton(enabled = f != null || err != null, onClick = { building = false }) { Text("Band") }
                }
            }
        )
    }
}

/* ------------------------- Preview ------------------------- */

@Composable
fun PreviewNode(n: Node, sel: Node?, onSel: (Node) -> Unit, defText: Color, rev: Int) {
    val isSel = sel === n
    val border = if (isSel) Modifier.border(2.dp, RcAccent) else Modifier.border(1.dp, Color(0x22FFFFFF))
    val defW = if (n.type == "button" || n.type == "input" || n.type == "row" || n.type == "column") "match" else "wrap"
    val w = n.props["w"] ?: defW
    val wMod: Modifier = when {
        w == "match" -> Modifier.fillMaxWidth()
        w == "wrap" || w.isBlank() -> Modifier
        else -> w.toIntOrNull()?.let { Modifier.width(it.dp) } ?: Modifier
    }
    val hMod: Modifier = (n.props["h"] ?: "").toIntOrNull()?.let { Modifier.height(it.dp) } ?: Modifier
    val pad = (n.props["padding"]?.toIntOrNull() ?: 0).dp
    val mar = (n.props["margin"]?.toIntOrNull() ?: 0).dp
    val m = Modifier.padding(mar).then(border).then(wMod).then(hMod).clickable { onSel(n) }.padding(pad)
    when (n.type) {
        "column" -> Column(m) { n.kids.forEach { PreviewNode(it, sel, onSel, defText, rev) } }
        "row" -> Row(m) { n.kids.forEach { PreviewNode(it, sel, onSel, defText, rev) } }
        "text" -> Text(
            n.props["text"] ?: "", color = colorOr(n.props["color"], defText),
            fontSize = (n.props["size"]?.toFloatOrNull() ?: 16f).sp,
            fontWeight = if (n.props["bold"] == "true") FontWeight.Bold else FontWeight.Normal,
            modifier = m
        )
        "button" -> Box(m) {
            Button(
                onClick = { onSel(n) }, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = colorOr(n.props["bg"], Color(0xFF7C4DFF)))
            ) { Text(n.props["text"] ?: "") }
        }
        "input" -> Box(m) {
            OutlinedTextField(
                value = n.props["text"] ?: "", onValueChange = {}, enabled = false,
                placeholder = { Text(n.props["hint"] ?: "") }, modifier = Modifier.fillMaxWidth()
            )
        }
        "image" -> Box(m.background(Color(0x33FFFFFF)), contentAlignment = Alignment.Center) {
            Text("IMG " + (n.props["src"] ?: ""), color = defText, fontSize = 10.sp)
        }
        else -> Spacer(m)
    }
}

/* ------------------------- Tree (drag reorder) ------------------------- */

@Composable
fun TreeTab(root: Node, sel: Node?, onSel: (Node) -> Unit, onChange: () -> Unit, onDelete: (Node) -> Unit) {
    val rows = ArrayList<TreeRow>()
    flatten(root, null, 0, rows)
    val rowPx = with(LocalDensity.current) { 48.dp.toPx() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text(
            "Row ko long-press karke upar/neeche drag karo. ▲▼ se bhi hilta hai.",
            color = RcMuted, fontSize = 11.sp, modifier = Modifier.padding(4.dp)
        )
        rows.forEach { row ->
            key(System.identityHashCode(row.node)) {
                Row(
                    Modifier.fillMaxWidth().height(48.dp)
                        .background(if (sel === row.node) RcCard else Color.Transparent)
                        .clickable { onSel(row.node) }
                        .pointerInput(row.node) {
                            var acc = 0f
                            detectDragGesturesAfterLongPress(
                                onDragStart = { acc = 0f },
                                onDrag = { change, amount ->
                                    change.consume()
                                    acc += amount.y
                                    val p = row.parent
                                    if (p != null) {
                                        if (acc > rowPx) {
                                            if (moveNode(p, row.node, 1)) onChange()
                                            acc = 0f
                                        } else if (acc < -rowPx) {
                                            if (moveNode(p, row.node, -1)) onChange()
                                            acc = 0f
                                        }
                                    }
                                },
                                onDragEnd = { },
                                onDragCancel = { }
                            )
                        }
                        .padding(start = (14 * row.depth).dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        (if (row.node.isContainer()) "▣ " else "▫ ") + row.node.type + " · " + row.node.id,
                        color = Color.White, fontSize = 13.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                    )
                    val p = row.parent
                    if (p != null) {
                        TextButton(onClick = { if (moveNode(p, row.node, -1)) onChange() }) { Text("▲") }
                        TextButton(onClick = { if (moveNode(p, row.node, 1)) onChange() }) { Text("▼") }
                        TextButton(onClick = { onDelete(row.node) }) { Text("✕") }
                    }
                }
            }
        }
    }
}

/* ------------------------- Properties ------------------------- */

@Composable
fun PropField(key: Any, label: String, value: String, onValue: (String) -> Unit) {
    var t by remember(key) { mutableStateOf(value) }
    OutlinedTextField(
        value = t, onValueChange = { t = it; onValue(it) }, singleLine = true,
        label = { Text(label, fontSize = 11.sp) }, modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun PropsTab(doc: RcDoc, screen: ScreenDef, sel: Node?, onDirty: () -> Unit, onDelete: (Node) -> Unit) {
    val common = listOf(
        "w" to "Width (match / wrap / number)", "h" to "Height (number)", "padding" to "Padding",
        "margin" to "Margin", "bg" to "Background color (#RRGGBB)", "weight" to "Weight",
        "visible" to "Visible (true / false)"
    )
    val perType = mapOf(
        "text" to listOf("text" to "Text", "size" to "Size", "color" to "Color", "bold" to "Bold (true / false)"),
        "button" to listOf("text" to "Text", "size" to "Size", "color" to "Text color"),
        "input" to listOf("hint" to "Hint", "text" to "Default text", "size" to "Size", "color" to "Color"),
        "image" to listOf("src" to "Image file (assets folder me)"),
        "row" to listOf("gravity" to "Gravity (center)"),
        "column" to listOf("gravity" to "Gravity (center)")
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Screen", color = RcAccent, fontWeight = FontWeight.Bold)
        PropField(screen, "Screen id", screen.id) { screen.id = it.trim(); onDirty() }
        PropField(screen, "Title", screen.title) { screen.title = it; onDirty() }
        PropField(screen, "Background", screen.bg) { screen.bg = it.trim(); onDirty() }
        Spacer(Modifier.height(10.dp))
        if (sel == null) {
            Text("Component ke properties ke liye Preview ya Tree me usse select karo.", color = RcMuted, fontSize = 12.sp)
        } else {
            Text(sel.type + " · " + sel.id, color = RcAccent, fontWeight = FontWeight.Bold)
            PropField(sel, "id (script me isi naam se milega)", sel.id) { sel.id = it.trim(); onDirty() }
            for ((k, label) in (perType[sel.type] ?: emptyList()) + common) {
                PropField(sel.id + k, label, sel.props[k] ?: "") { v -> sel.props[k] = v; onDirty() }
            }
            PropField(sel.id + "onClick", "onClick (script ka naam)", sel.props["onClick"] ?: "") { v ->
                sel.props["onClick"] = v
                onDirty()
            }
            if (doc.scripts.isNotEmpty()) {
                Text("Scripts (tap karke lagao, phir dobara Props kholo):", color = RcMuted, fontSize = 11.sp)
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    doc.scripts.keys.forEach { k ->
                        TextButton(onClick = {
                            sel.props["onClick"] = k
                            onDirty()
                        }) { Text(k) }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            if (sel.type != "column" || sel.id != "root") {
                MdeButton("Ye component delete karo", { onDelete(sel) })
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

/* ------------------------- Scripts (blocks + RC code) ------------------------- */

fun blockColor(line: String): Color {
    return when (line.trim().substringBefore(' ').lowercase()) {
        "if", "else", "end" -> Color(0xFF7A4A00)
        "set" -> Color(0xFF4A1F8F)
        "toast", "text", "show", "hide", "bg", "copy" -> Color(0xFF0B4F80)
        "encode", "decode" -> Color(0xFF9B1B6B)
        else -> Color(0xFF14612B)
    }
}

@Composable
fun ScriptsTab(doc: RcDoc, onDirty: () -> Unit, onStruct: () -> Unit) {
    var cur by remember { mutableStateOf(doc.scripts.keys.firstOrNull()) }
    var showNew by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var struct by remember { mutableIntStateOf(0) }
    val ctx = LocalContext.current

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            doc.scripts.keys.toList().forEach { k ->
                TextButton(onClick = { cur = k; msg = ""; struct++ }) {
                    Text(k, color = if (cur == k) RcAccent else RcMuted, fontWeight = if (cur == k) FontWeight.Bold else FontWeight.Normal)
                }
            }
            MdeButton("+ Script", { showNew = true })
        }
        val name = cur
        if (name == null || !doc.scripts.containsKey(name)) {
            Text("Koi script nahi. '+ Script' dabao.", color = RcMuted, modifier = Modifier.padding(8.dp))
        } else {
            val lines = (doc.scripts[name] ?: "").split("\n").toMutableList()
            fun store() {
                doc.scripts[name] = lines.joinToString("\n")
            }
            Text("Blocks jodo:", color = RcMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(
                    "toast" to "toast \"Hello\"", "set" to "set x = \"\"", "text" to "text id = \"\"",
                    "show" to "show id", "hide" to "hide id", "bg" to "bg id = \"#4CAF50\"",
                    "copy" to "copy get id", "encode" to "encode code = get msg, key",
                    "decode" to "decode out = get code",
                    "screen" to "screen main", "back" to "back",
                    "url" to "url \"https://\"", "run" to "run name", "if" to "if x == \"\"",
                    "else" to "else", "end" to "end"
                ).forEach { (lbl, tpl) ->
                    MdeButton(lbl, {
                        if (lines.size == 1 && lines[0].isBlank()) lines.clear()
                        lines.add(tpl)
                        store()
                        struct++
                        onStruct()
                    })
                }
            }
            Spacer(Modifier.height(6.dp))
            lines.forEachIndexed { i, ln ->
                key(name, i, struct) {
                    var t by remember { mutableStateOf(ln) }
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 3.dp)
                            .background(blockColor(t), RoundedCornerShape(8.dp)).padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = t,
                            onValueChange = {
                                t = it
                                if (i < lines.size) lines[i] = it
                                store()
                                onDirty()
                            },
                            singleLine = true, modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = {
                            if (i > 0) {
                                val x = lines.removeAt(i)
                                lines.add(i - 1, x)
                                store(); struct++; onStruct()
                            }
                        }) { Text("▲") }
                        TextButton(onClick = {
                            if (i < lines.size - 1) {
                                val x = lines.removeAt(i)
                                lines.add(i + 1, x)
                                store(); struct++; onStruct()
                            }
                        }) { Text("▼") }
                        TextButton(onClick = {
                            lines.removeAt(i)
                            store(); struct++; onStruct()
                        }) { Text("✕") }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MdeButton("Check", {
                    val e = RcLang.check(doc.scripts[name] ?: "")
                    msg = if (e == null) "✓ Script theek hai" else "✗ $e"
                })
                MdeButton("Script delete", {
                    doc.scripts.remove(name)
                    cur = doc.scripts.keys.firstOrNull()
                    struct++
                    onStruct()
                })
            }
            if (msg.isNotEmpty()) Text(msg, color = if (msg.startsWith("✓")) Color(0xFF4CAF50) else Color(0xFFFF7043), modifier = Modifier.padding(6.dp))
            Text(
                "RC code: set x = expr | toast expr | text id = expr | show id | hide id | " +
                    "bg id = \"#rrggbb\" | copy expr | encode out = message, key | decode out = code | " +
                    "screen id | back | url expr | run name | if a == b / else / end. " +
                    "expr: \"text\", number, x, get id, + - * /",
                color = RcMuted, fontSize = 10.sp, modifier = Modifier.padding(6.dp)
            )
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showNew) {
        InputDialog("Script ka naam (jaise: hello)", "", onOk = { n ->
            val id = n.replace(Regex("[^A-Za-z0-9_]"), "")
            if (id.isNotEmpty() && !doc.scripts.containsKey(id)) {
                doc.scripts[id] = ""
                cur = id
                struct++
                onStruct()
            } else {
                toast(ctx, "Naam khali ya pehle se hai")
            }
            showNew = false
        }, onCancel = { showNew = false })
    }
}
