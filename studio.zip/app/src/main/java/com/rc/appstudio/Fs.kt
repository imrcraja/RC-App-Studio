package com.rc.appstudio

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Fs {
    fun root(ctx: Context): File = File(ctx.filesDir, "projects").apply { mkdirs() }

    /** App ka apna "Downloads" folder. Yahan se user kisi bhi folder me save/share karta hai. */
    fun downloads(ctx: Context): File = File(ctx.filesDir, "downloads").apply { mkdirs() }

    fun projects(ctx: Context): List<File> =
        root(ctx).listFiles()?.filter { it.isDirectory }?.sortedBy { it.name.lowercase() }
            ?: emptyList()

    fun uniqueDir(ctx: Context, base: String): File {
        val clean = base.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "project" }
        var d = File(root(ctx), clean)
        var i = 1
        while (d.exists()) {
            d = File(root(ctx), "$clean-$i")
            i++
        }
        return d
    }

    fun displayName(cr: ContentResolver, uri: Uri): String {
        cr.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return "project.rc"
    }

    /** AI_CONTEXT.md ko app ke Downloads folder me rakhta hai (har baar taaza). */
    fun ensureAiContext(ctx: Context) {
        try {
            ctx.assets.open("AI_CONTEXT.md").use { ins ->
                File(downloads(ctx), "AI_CONTEXT.md").outputStream().use { ins.copyTo(it) }
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    fun importUri(ctx: Context, uri: Uri): File {
        val name = displayName(ctx.contentResolver, uri)
        val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("File khul nahi rahi")
        return importStream(ctx, name, input)
    }

    /**
     * .rc ya .zip kholta hai.
     * .rc = zip jisme rc.json + project/ folder hota hai.
     * Plain zip ho to seedha project maanta hai (ek hi root folder ho to hata deta hai).
     */
    fun importStream(ctx: Context, fileName: String, input: InputStream): File {
        val base = fileName.replace(Regex("\\.(zip|rc)$", RegexOption.IGNORE_CASE), "")
        val tmp = File(ctx.cacheDir, "imp_" + System.nanoTime()).apply { mkdirs() }
        try {
            ZipInputStream(BufferedInputStream(input)).use { zin ->
                var e: ZipEntry? = zin.nextEntry
                while (e != null) {
                    val out = File(tmp, e.name)
                    if (!out.canonicalPath.startsWith(tmp.canonicalPath + File.separator)) {
                        throw IOException("Unsafe zip entry: " + e.name)
                    }
                    if (e.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { fo -> zin.copyTo(fo) }
                    }
                    zin.closeEntry()
                    e = zin.nextEntry
                }
            }
            var name = base
            val rcJson = File(tmp, "rc.json")
            val projDir = File(tmp, "project")
            val src: File
            if (rcJson.isFile && projDir.isDirectory) {
                try {
                    name = JSONObject(rcJson.readText()).optString("name", base)
                } catch (e: Exception) {
                    // manifest kharab ho to file ka naam use hoga
                }
                src = projDir
            } else {
                val kids = tmp.listFiles() ?: emptyArray()
                src = if (kids.size == 1 && kids[0].isDirectory) kids[0] else tmp
            }
            val dest = uniqueDir(ctx, name)
            if (!src.copyRecursively(dest, overwrite = true)) throw IOException("Copy fail")
            return dest
        } finally {
            tmp.deleteRecursively()
        }
    }

    fun zipTo(dir: File, out: OutputStream) {
        ZipOutputStream(BufferedOutputStream(out)).use { z ->
            dir.walkTopDown().filter { it.isFile }.forEach { f ->
                val rel = f.relativeTo(dir).path.replace(File.separatorChar, '/')
                z.putNextEntry(ZipEntry(rel))
                f.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
    }

    fun zipBytes(dir: File): ByteArray {
        val bos = ByteArrayOutputStream()
        zipTo(dir, bos)
        return bos.toByteArray()
    }

    /** Project ko plain zip banake app ke Downloads me rakhta hai. */
    fun exportZip(ctx: Context, project: File): File {
        val out = File(downloads(ctx), project.name + ".zip")
        FileOutputStream(out).use { zipTo(project, it) }
        return out
    }

    fun isText(f: File): Boolean {
        if (f.length() > 1_000_000) return false
        val buf = ByteArray(4096)
        val n = f.inputStream().use { it.read(buf) }
        for (i in 0 until maxOf(n, 0)) {
            if (buf[i].toInt() == 0) return false
        }
        return true
    }

    fun safeChild(project: File, dir: File, name: String): File? {
        if (name.isBlank()) return null
        val f = File(dir, name)
        return if (f.canonicalPath.startsWith(project.canonicalPath + File.separator)) f else null
    }

    fun sizeText(f: File): String {
        val b = f.length()
        return when {
            b < 1024 -> "$b B"
            b < 1024 * 1024 -> "${b / 1024} KB"
            else -> "${b / (1024 * 1024)} MB"
        }
    }
}
