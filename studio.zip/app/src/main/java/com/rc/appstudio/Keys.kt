package com.rc.appstudio

import android.content.Context
import com.android.apksig.ApkSigner
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.Date
import java.util.UUID

/** APK sign karne ke liye apna keystore (phone me hi banta hai). */
object Keys {
    private const val ALIAS = "rc"

    private fun file(ctx: Context) = File(ctx.filesDir, "rc-keystore.p12")

    fun password(ctx: Context): String {
        val p = ctx.getSharedPreferences("keys", Context.MODE_PRIVATE)
        var s = p.getString("pass", null)
        if (s == null) {
            s = UUID.randomUUID().toString().replace("-", "")
            p.edit().putString("pass", s).apply()
        }
        return s
    }

    private fun generate(ctx: Context) {
        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048)
        val kp = kpg.generateKeyPair()
        val name = X500Name("CN=RC App Studio, O=RC")
        val now = System.currentTimeMillis()
        val builder = JcaX509v3CertificateBuilder(
            name, BigInteger.valueOf(now),
            Date(now - 86400000L), Date(now + 10000L * 86400000L),
            name, kp.public
        )
        val signer = JcaContentSignerBuilder("SHA256withRSA").build(kp.private)
        val cert = JcaX509CertificateConverter().getCertificate(builder.build(signer))
        val ks = KeyStore.getInstance("PKCS12")
        ks.load(null, null)
        ks.setKeyEntry(ALIAS, kp.private, password(ctx).toCharArray(), arrayOf(cert))
        FileOutputStream(file(ctx)).use { ks.store(it, password(ctx).toCharArray()) }
    }

    private fun load(ctx: Context): Pair<PrivateKey, X509Certificate> {
        if (!file(ctx).exists()) generate(ctx)
        val ks = KeyStore.getInstance("PKCS12")
        FileInputStream(file(ctx)).use { ks.load(it, password(ctx).toCharArray()) }
        val key = ks.getKey(ALIAS, password(ctx).toCharArray()) as PrivateKey
        val cert = ks.getCertificate(ALIAS) as X509Certificate
        return Pair(key, cert)
    }

    fun sign(ctx: Context, inApk: File, outApk: File) {
        val kc = load(ctx)
        val cfg = ApkSigner.SignerConfig.Builder("rc", kc.first, listOf(kc.second)).build()
        if (outApk.exists()) outApk.delete()
        ApkSigner.Builder(listOf(cfg))
            .setInputApk(inApk)
            .setOutputApk(outApk)
            .setMinSdkVersion(24)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .build()
            .sign()
    }

    /** Keystore ki copy Downloads me rakhta hai (backup). Password wapas karta hai. */
    fun backup(ctx: Context): Pair<File, String> {
        if (!file(ctx).exists()) generate(ctx)
        val out = File(Fs.downloads(ctx), "rc-keystore.p12")
        file(ctx).copyTo(out, overwrite = true)
        return Pair(out, password(ctx))
    }
}
