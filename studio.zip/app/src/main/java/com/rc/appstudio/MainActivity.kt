package com.rc.appstudio

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

val RcBg = Color(0xFF000216)
val RcCard = Color(0xFF0A0F2E)
val RcMuted = Color(0xFF8FA3C8)
val RcAccent = Color(0xFF29B6F6)

private val Scheme = darkColorScheme(
    background = RcBg, surface = RcBg, surfaceVariant = RcCard,
    primary = Color(0xFF7C4DFF), secondary = RcAccent,
    onBackground = Color.White, onSurface = Color.White, onPrimary = Color.White
)

sealed class Screen {
    object Home : Screen()
    data class Files(val project: File, val dir: File) : Screen()
    data class Editor(val project: File, val file: File) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = Scheme) {
                Box(Modifier.fillMaxSize().background(RcBg)) { StudioApp() }
            }
        }
    }
}

fun toast(ctx: Context, m: String) {
    Toast.makeText(ctx, m, Toast.LENGTH_LONG).show()
}

@Composable
fun MdeButton(text: String, onClick: () -> Unit, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        enabled = enabled,
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
    ) { Text(text, fontSize = 13.sp) }
}

@Composable
fun InputDialog(title: String, initial: String, onOk: (String) -> Unit, onCancel: () -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title) },
        text = { OutlinedTextField(value = v, onValueChange = { v = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onOk(v.trim()) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } }
    )
}

@Composable
fun ConfirmDialog(title: String, msg: String, onYes: () -> Unit, onNo: () -> Unit) {
    AlertDialog(
        onDismissRequest = onNo,
        title = { Text(title) },
        text = { Text(msg) },
        confirmButton = { TextButton(onClick = onYes) { Text("Haan") } },
        dismissButton = { TextButton(onClick = onNo) { Text("Nahi") } }
    )
}

@Composable
fun StudioApp() {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var tab by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { Fs.ensureAiContext(ctx) }
    }

    when (val s = screen) {
        is Screen.Home -> HomeScreen(tab, { tab = it }, onOpen = { screen = Screen.Files(it, it) })
        is Screen.Files -> FilesScreen(s.project, s.dir, go = { screen = it })
        is Screen.Editor -> EditorScreen(
            s.project, s.file,
            onClose = { screen = Screen.Files(s.project, s.file.parentFile ?: s.project) }
        )
    }
}

/* ------------------------- Home ------------------------- */

@Composable
fun HomeScreen(tab: Int, onTab: (Int) -> Unit, onOpen: (File) -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.rc_logo), null, Modifier.size(48.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("RC App Studio", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Import  •  Edit  •  Build", color = RcMuted, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            listOf("Projects", "AI", "Assets", "Downloads", "Settings").forEachIndexed { i, t ->
                TextButton(onClick = { onTab(i) }) {
                    Text(
                        t,
                        color = if (tab == i) RcAccent else RcMuted,
                        fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 15.sp
                    )
                }
            }
        }
        when (tab) {
            0 -> ProjectsTab(onOpen)
            1 -> AiTab()
            2 -> AssetsTab()
            3 -> DownloadsTab()
            else -> SettingsTab()
        }
    }
}

@Composable
fun ColumnScope.ProjectsTab(onOpen: (File) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val projects = remember(tick) { Fs.projects(ctx) }
    var showNew by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<File?>(null) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val d = withContext(Dispatchers.IO) { Fs.importUri(ctx, uri) }
                    tick++
                    toast(ctx, "Import ho gaya: " + d.name)
                } catch (e: Exception) {
                    toast(ctx, "Import fail: " + e.message)
                }
            }
        }
    }

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MdeButton("Import (.rc / .zip)", { importLauncher.launch(arrayOf("*/*")) })
        MdeButton("Naya project", { showNew = true })
    }
    Spacer(Modifier.height(10.dp))
    if (projects.isEmpty()) {
        Text("Abhi koi project nahi. .rc ya .zip import karo, ya naya banao.", color = RcMuted)
    }
    LazyColumn(Modifier.weight(1f)) {
        items(projects) { p ->
            Row(
                Modifier.fillMaxWidth().clickable { onOpen(p) }.padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("📦 ", fontSize = 18.sp)
                Text(
                    p.name, color = Color.White, fontSize = 16.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = {
                    scope.launch {
                        try {
                            val f = withContext(Dispatchers.IO) { Rc.export(ctx, p) }
                            toast(ctx, "Downloads me save hua: " + f.name)
                        } catch (e: Exception) {
                            toast(ctx, "Export fail: " + e.message)
                        }
                    }
                }) { Text(".rc") }
                TextButton(onClick = { toDelete = p }) { Text("Delete") }
            }
        }
    }

    if (showNew) {
        InputDialog("Project ka naam", "", onOk = { n ->
            if (n.isNotBlank()) {
                val d = Fs.uniqueDir(ctx, n)
                d.mkdirs()
                File(d, "PROJECT_NOTES.md").writeText(
                    "# " + d.name + "\n\n## Goal\n\n## Status\n\n## Decisions\n\n## Next steps\n"
                )
                tick++
            }
            showNew = false
        }, onCancel = { showNew = false })
    }
    val del = toDelete
    if (del != null) {
        ConfirmDialog("Delete?", "'" + del.name + "' poora hata dein?", onYes = {
            del.deleteRecursively()
            toDelete = null
            tick++
        }, onNo = { toDelete = null })
    }
}

/* ------------------------- Files ------------------------- */

@Composable
fun FilesScreen(project: File, dir: File, go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val entries = remember(dir, tick) {
        (dir.listFiles()?.toList() ?: emptyList())
            .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
    }
    var newKind by remember { mutableStateOf<String?>(null) }
    var renameFile by remember { mutableStateOf<File?>(null) }
    var deleteFile by remember { mutableStateOf<File?>(null) }
    var menuFor by remember { mutableStateOf<File?>(null) }
    var showGh by remember { mutableStateOf(false) }
    var showApp by remember { mutableStateOf(false) }

    BackHandler {
        if (dir == project) go(Screen.Home)
        else go(Screen.Files(project, dir.parentFile ?: project))
    }

    val rel = dir.relativeTo(project).path
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                if (dir == project) go(Screen.Home)
                else go(Screen.Files(project, dir.parentFile ?: project))
            }) { Text("←", fontSize = 20.sp) }
            Text(
                project.name + (if (rel.isEmpty()) "" else "/$rel"),
                color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold
            )
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MdeButton("+ File", { newKind = "file" })
            MdeButton("+ Folder", { newKind = "folder" })
            MdeButton("Export .rc", {
                scope.launch {
                    try {
                        val f = withContext(Dispatchers.IO) { Rc.export(ctx, project) }
                        toast(ctx, "Downloads me save hua: " + f.name)
                    } catch (e: Exception) {
                        toast(ctx, "Export fail: " + e.message)
                    }
                }
            })
            MdeButton("Export zip", {
                scope.launch {
                    try {
                        val f = withContext(Dispatchers.IO) { Fs.exportZip(ctx, project) }
                        toast(ctx, "Downloads me save hua: " + f.name)
                    } catch (e: Exception) {
                        toast(ctx, "Export fail: " + e.message)
                    }
                }
            })
            MdeButton("App settings", { showApp = true })
            MdeButton("GitHub push", { showGh = true })
        }
        Spacer(Modifier.height(8.dp))
        if (entries.isEmpty()) Text("Folder khali hai.", color = RcMuted)
        LazyColumn(Modifier.weight(1f)) {
            items(entries) { f ->
                Row(
                    Modifier.fillMaxWidth().clickable {
                        if (f.isDirectory) go(Screen.Files(project, f))
                        else if (Fs.isText(f)) go(Screen.Editor(project, f))
                        else toast(ctx, "Ye binary file hai (image/video), edit nahi ho sakti")
                    }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (f.isDirectory) "📁 " else "📄 ", fontSize = 16.sp)
                    Column(Modifier.weight(1f)) {
                        Text(f.name, color = Color.White, fontSize = 15.sp)
                        if (f.isFile) Text(Fs.sizeText(f), color = RcMuted, fontSize = 11.sp)
                    }
                    Box {
                        TextButton(onClick = { menuFor = f }) { Text("⋮", fontSize = 18.sp) }
                        DropdownMenu(expanded = menuFor == f, onDismissRequest = { menuFor = null }) {
                            DropdownMenuItem(text = { Text("Rename") }, onClick = {
                                renameFile = f
                                menuFor = null
                            })
                            DropdownMenuItem(text = { Text("Delete") }, onClick = {
                                deleteFile = f
                                menuFor = null
                            })
                        }
                    }
                }
            }
        }
    }

    val kind = newKind
    if (kind != null) {
        InputDialog(
            if (kind == "file") "Nayi file (jaise app/Main.kt)" else "Naya folder",
            "",
            onOk = { n ->
                val target = Fs.safeChild(project, dir, n)
                if (target == null) {
                    toast(ctx, "Naam theek nahi hai")
                } else {
                    try {
                        if (kind == "file") {
                            target.parentFile?.mkdirs()
                            target.createNewFile()
                        } else {
                            target.mkdirs()
                        }
                    } catch (e: Exception) {
                        toast(ctx, "Fail: " + e.message)
                    }
                }
                newKind = null
                tick++
            },
            onCancel = { newKind = null }
        )
    }
    val rf = renameFile
    if (rf != null) {
        InputDialog("Naya naam", rf.name, onOk = { n ->
            val target = Fs.safeChild(project, rf.parentFile ?: dir, n)
            if (target == null || !rf.renameTo(target)) toast(ctx, "Rename nahi hua")
            renameFile = null
            tick++
        }, onCancel = { renameFile = null })
    }
    val df = deleteFile
    if (df != null) {
        ConfirmDialog("Delete?", "'" + df.name + "' hata dein?", onYes = {
            df.deleteRecursively()
            deleteFile = null
            tick++
        }, onNo = { deleteFile = null })
    }
    if (showGh) GithubDialog(project, onClose = { showGh = false })
    if (showApp) AppSettingsDialog(project, onClose = { showApp = false })
}

/* ------------------------- GitHub ------------------------- */

@Composable
fun GithubDialog(project: File, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val saved = remember { Github.load(ctx) }
    var token by remember { mutableStateOf(saved.token) }
    var owner by remember { mutableStateOf(saved.owner) }
    var repo by remember { mutableStateOf(saved.repo) }
    var branch by remember { mutableStateOf(saved.branch) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = { Text("GitHub par push") },
        text = {
            Column(Modifier.horizontalScroll(rememberScrollState()).width(280.dp)) {
                OutlinedTextField(
                    value = token, onValueChange = { token = it },
                    label = { Text("Token") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                OutlinedTextField(
                    value = owner, onValueChange = { owner = it },
                    label = { Text("Username / owner") }, singleLine = true
                )
                OutlinedTextField(
                    value = repo, onValueChange = { repo = it },
                    label = { Text("Repo ka naam") }, singleLine = true
                )
                OutlinedTextField(
                    value = branch, onValueChange = { branch = it },
                    label = { Text("Branch (khali = default)") }, singleLine = true
                )
                if (status.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Text(status, color = RcMuted, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                val cfg = Github.Cfg(token.trim(), owner.trim(), repo.trim(), branch.trim())
                if (cfg.token.isEmpty() || cfg.owner.isEmpty() || cfg.repo.isEmpty()) {
                    status = "Token, owner aur repo bharo"
                } else {
                    Github.save(ctx, cfg)
                    busy = true
                    status = "Zip bana kar bhej raha hoon..."
                    scope.launch {
                        status = try {
                            withContext(Dispatchers.IO) {
                                Github.pushZip(cfg, Fs.zipBytes(project), "Update from RC App Studio")
                            }
                        } catch (e: Exception) {
                            "Fail: " + e.message
                        }
                        busy = false
                    }
                }
            }) { Text(if (busy) "Bhej raha hoon..." else "Push") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = {
                    if (owner.isNotBlank() && repo.isNotBlank()) {
                        val u = "https://github.com/" + owner.trim() + "/" + repo.trim() + "/actions"
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
                    }
                }) { Text("Actions") }
                TextButton(enabled = !busy, onClick = onClose) { Text("Band") }
            }
        }
    )
}

/* ------------------------- Editor ------------------------- */

@Composable
fun EditorScreen(project: File, file: File, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var text by remember(file) { mutableStateOf(file.readText()) }
    var savedText by remember(file) { mutableStateOf(text) }
    var askExit by remember { mutableStateOf(false) }
    val dirty = text != savedText

    fun save() {
        try {
            file.writeText(text)
            savedText = text
            toast(ctx, "Save ho gaya")
        } catch (e: Exception) {
            toast(ctx, "Save fail: " + e.message)
        }
    }

    BackHandler { if (dirty) askExit = true else onClose() }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding().padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { if (dirty) askExit = true else onClose() }) {
                Text("←", fontSize = 20.sp)
            }
            Text(
                file.name + (if (dirty) " •" else ""),
                color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold
            )
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MdeButton("Save", { save() })
            MdeButton("Paste (sab badlo)", {
                val t = clip.getText()
                if (t != null) text = t.text else toast(ctx, "Clipboard khali hai")
            })
            MdeButton("Copy all", { clip.setText(AnnotatedString(text)) })
        }
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.fillMaxWidth().weight(1f),
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = Color.White)
        )
    }

    if (askExit) {
        AlertDialog(
            onDismissRequest = { askExit = false },
            title = { Text("Save karein?") },
            text = { Text("Badlav save nahi hue hain.") },
            confirmButton = {
                TextButton(onClick = {
                    save()
                    askExit = false
                    onClose()
                }) { Text("Save") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        askExit = false
                        onClose()
                    }) { Text("Chhodo") }
                    TextButton(onClick = { askExit = false }) { Text("Cancel") }
                }
            }
        )
    }
}
