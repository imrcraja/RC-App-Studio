package com.rc.appstudio

import android.content.Context

object Prefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("rc", Context.MODE_PRIVATE)

    fun deviceAssets(ctx: Context): Boolean = p(ctx).getBoolean("deviceAssets", false)
    fun setDeviceAssets(ctx: Context, v: Boolean) {
        p(ctx).edit().putBoolean("deviceAssets", v).apply()
    }

    fun tree(ctx: Context): String? = p(ctx).getString("tree", null)
    fun setTree(ctx: Context, s: String?) {
        p(ctx).edit().putString("tree", s).apply()
    }

    fun skipConfirm(ctx: Context): Boolean = p(ctx).getBoolean("skipConfirm", false)
    fun setSkipConfirm(ctx: Context, v: Boolean) {
        p(ctx).edit().putBoolean("skipConfirm", v).apply()
    }

    fun pending(ctx: Context): String = p(ctx).getString("pending", "[]") ?: "[]"
    fun setPending(ctx: Context, s: String) {
        p(ctx).edit().putString("pending", s).apply()
    }
}
