package com.rc.appstudio

import android.content.Context
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * .rc = RC App Studio ka project format (Sketchware ke .swb jaisa).
 * Andar se ek normal ZIP hai:
 *   rc.json          -> manifest (format, formatVersion, name, exportedAt, fileCount)
 *   AI_CONTEXT.md    -> koi bhi AI isse padhkar poora mamla samajh sakta hai
 *   project/...      -> project ki asli files
 */
object Rc {
    const val FORMAT = "rc-project"
    const val VERSION = 1

    fun export(ctx: Context, project: File): File {
        val out = File(Fs.downloads(ctx), project.name + ".rc")
        val files = project.walkTopDown().filter { it.isFile }.toList()
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")

        val manifest = JSONObject()
        manifest.put("format", FORMAT)
        manifest.put("formatVersion", VERSION)
        manifest.put("name", project.name)
        manifest.put("createdWith", "RC App Studio")
        manifest.put("exportedAt", fmt.format(Date()))
        manifest.put("fileCount", files.size)
        manifest.put("note", "Zip container. Project files are under project/. AI: read AI_CONTEXT.md first.")

        ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { z ->
            z.putNextEntry(ZipEntry("rc.json"))
            z.write(manifest.toString(2).toByteArray())
            z.closeEntry()

            try {
                ctx.assets.open("AI_CONTEXT.md").use { ins ->
                    z.putNextEntry(ZipEntry("AI_CONTEXT.md"))
                    ins.copyTo(z)
                    z.closeEntry()
                }
            } catch (e: Exception) {
                // context na mile to bhi export chalega
            }

            for (f in files) {
                val rel = f.relativeTo(project).path.replace(File.separatorChar, '/')
                z.putNextEntry(ZipEntry("project/$rel"))
                f.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
        return out
    }
}
