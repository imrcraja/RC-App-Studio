package com.rc.appstudio

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

@Composable
fun SectionTitle(t: String) {
    Text(t, color = RcAccent, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
}

@Composable
fun ColumnScope.SettingsTab() {
    val ctx = LocalContext.current
    var dev by remember { mutableStateOf(Prefs.deviceAssets(ctx)) }
    var skip by remember { mutableStateOf(Prefs.skipConfirm(ctx)) }
    var tree by remember { mutableStateOf(Prefs.tree(ctx)) }
    val c0 = remember { Cloud.load(ctx) }
    var mode by remember { mutableStateOf(c0.mode) }
    var curl by remember { mutableStateOf(c0.url) }
    var ckey by remember { mutableStateOf(c0.key) }
    var bucket by remember { mutableStateOf(c0.bucket) }

    var ksInfo by remember { mutableStateOf<String?>(null) }
    val treeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // kuch phones par persist nahi hota
            }
            Prefs.setTree(ctx, uri.toString())
            tree = uri.toString()
        }
    }

    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        SectionTitle("Storage")
        Text(
            "Project hamesha app ke apne files folder me rehte hain, taaki offline kaam kare. " +
                "Cloud sirf backup/sync ke liye hai (abhi Supabase Storage).",
            color = RcMuted, fontSize = 12.sp
        )
        Row {
            listOf("local" to "Local", "cloud" to "Cloud", "both" to "Dono").forEach { (k, label) ->
                TextButton(onClick = {
                    mode = k
                    Cloud.save(ctx, Cloud.Cfg(k, curl, ckey, bucket))
                }) {
                    Text(
                        label, color = if (mode == k) RcAccent else RcMuted,
                        fontWeight = if (mode == k) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
        if (mode != "local") {
            OutlinedTextField(
                value = curl, onValueChange = { curl = it }, singleLine = true,
                label = { Text("Supabase URL (https://xxxx.supabase.co)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = ckey, onValueChange = { ckey = it }, singleLine = true,
                label = { Text("Supabase key") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = bucket, onValueChange = { bucket = it }, singleLine = true,
                label = { Text("Bucket ka naam") }, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            MdeButton("Cloud details save karo", {
                Cloud.save(ctx, Cloud.Cfg(mode, curl.trim(), ckey.trim(), bucket.trim()))
                toast(ctx, "Save ho gaya. Downloads me ab 'Cloud ↑' dikhega.")
            })
        }

        SectionTitle("Assets")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Device ke assets use karo", color = Color.White, fontSize = 14.sp)
                Text(
                    "ON: net na ho to aapke chune hue folder me asset dhundhega. " +
                        "OFF: device ko chhuega nahi, code se built-in banayega aur net aane par download karega.",
                    color = RcMuted, fontSize = 11.sp
                )
            }
            Switch(checked = dev, onCheckedChange = {
                dev = it
                Prefs.setDeviceAssets(ctx, it)
            })
        }
        if (dev) {
            Spacer(Modifier.height(4.dp))
            MdeButton("Folder chuno", { treeLauncher.launch(null) })
            Text(
                if (tree == null) "Abhi koi folder nahi chuna" else "Folder chuna hua hai",
                color = RcMuted, fontSize = 11.sp
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 10.dp)) {
            Column(Modifier.weight(1f)) {
                Text("Download se pehle size na dikhao", color = Color.White, fontSize = 14.sp)
                Text("OFF rakhoge to har download se pehle MB dikhega.", color = RcMuted, fontSize = 11.sp)
            }
            Switch(checked = skip, onCheckedChange = {
                skip = it
                Prefs.setSkipConfirm(ctx, it)
            })
        }

        SectionTitle("APK signing (keystore)")
        Text(
            "Apps isi keystore se sign hote hain. Update ke liye har baar yahi keystore chahiye, isliye backup zaroor lo " +
                "(app uninstall karne par keystore chala jata hai).",
            color = RcMuted, fontSize = 12.sp
        )
        Spacer(Modifier.height(4.dp))
        MdeButton("Keystore backup (Downloads me)", {
            try {
                val kb = Keys.backup(ctx)
                ksInfo = "File: " + kb.first.name + "\nPassword: " + kb.second + "\nAlias: rc\n\nFile Downloads tab me hai. Password kahin safe likh lo."
            } catch (e: Exception) {
                toast(ctx, "Backup fail: " + e.message)
            }
        })

        SectionTitle("AI Context")
        Text(
            "AI_CONTEXT.md Downloads me hai. Kisi bhi AI ko do, wo RC App Studio aur tumhare projects ka poora mamla samajh jayega.",
            color = RcMuted, fontSize = 12.sp
        )
        Spacer(Modifier.height(4.dp))
        MdeButton("AI Context dobara banao", {
            Fs.ensureAiContext(ctx)
            toast(ctx, "Downloads me taaza AI_CONTEXT.md hai")
        })

        SectionTitle("About")
        Text("RC App Studio 0.4", color = Color.White, fontSize = 13.sp)
        Text(
            "Tokens aur keys sirf is phone ke private storage me rehte hain. " +
                "GitHub token hamesha sirf ek repo ka, Contents: Read and write wala banao.",
            color = RcMuted, fontSize = 11.sp
        )
        Spacer(Modifier.height(24.dp))
    }
    val ki = ksInfo
    if (ki != null) {
        AlertDialog(
            onDismissRequest = { ksInfo = null },
            title = { Text("Keystore backup") },
            text = { Text(ki) },
            confirmButton = { TextButton(onClick = { ksInfo = null }) { Text("OK") } }
        )
    }
}

fun parseColor(h: String): Color = try {
    Color(android.graphics.Color.parseColor(h.trim()))
} catch (e: Exception) {
    Color.Gray
}

@Composable
fun AppSettingsDialog(project: File, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val c0 = remember { AppCfg.load(project) }
    var name by remember { mutableStateOf(c0.appName) }
    var pkg by remember { mutableStateOf(c0.packageName) }
    var vName by remember { mutableStateOf(c0.versionName) }
    var vCode by remember { mutableIntStateOf(c0.versionCode) }
    var color by remember { mutableStateOf(c0.primaryColor) }
    var logo by remember { mutableStateOf(c0.logo) }

    val logoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val dn = Fs.displayName(ctx.contentResolver, uri)
                val ext = dn.substringAfterLast('.', "png").lowercase()
                val out = File(project, "assets/logo.$ext")
                out.parentFile?.mkdirs()
                val ins = ctx.contentResolver.openInputStream(uri)
                if (ins != null) {
                    ins.use { i -> out.outputStream().use { i.copyTo(it) } }
                    logo = "assets/logo.$ext"
                }
            } catch (e: Exception) {
                toast(ctx, "Logo fail: " + e.message)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("App settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()).width(290.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("App ka naam") })
                OutlinedTextField(value = pkg, onValueChange = { pkg = it }, singleLine = true, label = { Text("Package (com.naam.app)") })
                OutlinedTextField(value = vName, onValueChange = { vName = it }, singleLine = true, label = { Text("Version name") })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Version code: $vCode", color = Color.White, modifier = Modifier.weight(1f))
                    TextButton(onClick = { if (vCode > 1) vCode-- }) { Text("−", fontSize = 20.sp) }
                    TextButton(onClick = { vCode++ }) { Text("+", fontSize = 20.sp) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = color, onValueChange = { color = it }, singleLine = true,
                        label = { Text("Primary color") }, modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.size(32.dp).background(parseColor(color), RoundedCornerShape(6.dp)))
                }
                Spacer(Modifier.height(6.dp))
                MdeButton("Logo chuno", { logoLauncher.launch(arrayOf("image/*")) })
                Text(if (logo.isEmpty()) "Logo nahi chuna" else "Logo: $logo", color = RcMuted, fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                AppCfg.save(project, AppCfg.Cfg(name.trim(), pkg.trim(), vName.trim(), vCode, color.trim(), logo))
                toast(ctx, "rc-app.json save ho gaya")
                onClose()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}
