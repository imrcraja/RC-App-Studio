package com.rc.appstudio

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** UI language: a phone-only picker with these languages; changing it saves immediately. */
data class LangOpt(val code: String, val native: String, val english: String)

val LANGUAGES = listOf(
    LangOpt("en", "English", "English"),
    LangOpt("hi", "हिन्दी", "Hindi"),
    LangOpt("es", "Español", "Spanish"),
    LangOpt("fr", "Français", "French"),
    LangOpt("de", "Deutsch", "German"),
    LangOpt("pt", "Português", "Portuguese"),
    LangOpt("ru", "Русский", "Russian"),
    LangOpt("ar", "العربية", "Arabic"),
    LangOpt("zh", "中文", "Chinese"),
    LangOpt("ja", "日本語", "Japanese"),
)

object Lang {
    var current by mutableStateOf("en")
        private set

    fun load(ctx: Context) {
        current = ctx.getSharedPreferences("lang", Context.MODE_PRIVATE).getString("code", "en") ?: "en"
    }

    fun set(ctx: Context, code: String) {
        current = code
        ctx.getSharedPreferences("lang", Context.MODE_PRIVATE).edit().putString("code", code).apply()
    }
}

/** Looks up a UI string in the current language; falls back to English, then the key itself. */
fun t(key: String): String {
    val row = Str.table[key] ?: return key
    return row[Lang.current] ?: row["en"] ?: key
}

object Str {
    val table: Map<String, Map<String, String>> = mapOf(
        "nav_projects" to mapOf("en" to "Projects", "hi" to "प्रोजेक्ट्स", "es" to "Proyectos", "fr" to "Projets", "de" to "Projekte", "pt" to "Projetos", "ru" to "Проекты", "ar" to "المشاريع", "zh" to "项目", "ja" to "プロジェクト"),
        "nav_ai" to mapOf("en" to "AI", "hi" to "एआई", "es" to "IA", "fr" to "IA", "de" to "KI", "pt" to "IA", "ru" to "ИИ", "ar" to "الذكاء الاصطناعي", "zh" to "人工智能", "ja" to "AI"),
        "nav_assets" to mapOf("en" to "Assets", "hi" to "एसेट्स", "es" to "Recursos", "fr" to "Ressources", "de" to "Assets", "pt" to "Recursos", "ru" to "Ресурсы", "ar" to "الأصول", "zh" to "资源", "ja" to "アセット"),
        "nav_downloads" to mapOf("en" to "Downloads", "hi" to "डाउनलोड्स", "es" to "Descargas", "fr" to "Téléchargements", "de" to "Downloads", "pt" to "Downloads", "ru" to "Загрузки", "ar" to "التنزيلات", "zh" to "下载", "ja" to "ダウンロード"),
        "nav_settings" to mapOf("en" to "Settings", "hi" to "सेटिंग्स", "es" to "Ajustes", "fr" to "Paramètres", "de" to "Einstellungen", "pt" to "Configurações", "ru" to "Настройки", "ar" to "الإعدادات", "zh" to "设置", "ja" to "設定"),
        "app_title" to mapOf("en" to "RC App Studio", "hi" to "आरसी ऐप स्टूडियो", "es" to "RC App Studio", "fr" to "RC App Studio", "de" to "RC App Studio", "pt" to "RC App Studio", "ru" to "RC App Studio", "ar" to "RC App Studio", "zh" to "RC App Studio", "ja" to "RC App Studio"),
        "app_subtitle" to mapOf("en" to "Import · Edit · Build", "hi" to "इम्पोर्ट · एडिट · बिल्ड", "es" to "Importar · Editar · Compilar", "fr" to "Importer · Modifier · Compiler", "de" to "Importieren · Bearbeiten · Erstellen", "pt" to "Importar · Editar · Compilar", "ru" to "Импорт · Правка · Сборка", "ar" to "استيراد · تحرير · بناء", "zh" to "导入 · 编辑 · 构建", "ja" to "インポート・編集・ビルド"),
        "btn_save" to mapOf("en" to "Save", "hi" to "सेव करें", "es" to "Guardar", "fr" to "Enregistrer", "de" to "Speichern", "pt" to "Salvar", "ru" to "Сохранить", "ar" to "حفظ", "zh" to "保存", "ja" to "保存"),
        "btn_cancel" to mapOf("en" to "Cancel", "hi" to "रद्द करें", "es" to "Cancelar", "fr" to "Annuler", "de" to "Abbrechen", "pt" to "Cancelar", "ru" to "Отмена", "ar" to "إلغاء", "zh" to "取消", "ja" to "キャンセル"),
        "btn_delete" to mapOf("en" to "Delete", "hi" to "हटाएं", "es" to "Eliminar", "fr" to "Supprimer", "de" to "Löschen", "pt" to "Excluir", "ru" to "Удалить", "ar" to "حذف", "zh" to "删除", "ja" to "削除"),
        "btn_import" to mapOf("en" to "Import", "hi" to "इम्पोर्ट करें", "es" to "Importar", "fr" to "Importer", "de" to "Importieren", "pt" to "Importar", "ru" to "Импорт", "ar" to "استيراد", "zh" to "导入", "ja" to "インポート"),
        "btn_export" to mapOf("en" to "Export", "hi" to "एक्सपोर्ट करें", "es" to "Exportar", "fr" to "Exporter", "de" to "Exportieren", "pt" to "Exportar", "ru" to "Экспорт", "ar" to "تصدير", "zh" to "导出", "ja" to "エクスポート"),
        "btn_share" to mapOf("en" to "Share", "hi" to "शेयर करें", "es" to "Compartir", "fr" to "Partager", "de" to "Teilen", "pt" to "Compartilhar", "ru" to "Поделиться", "ar" to "مشاركة", "zh" to "分享", "ja" to "共有"),
        "btn_build_apk" to mapOf("en" to "Build APK", "hi" to "एपीके बनाएं", "es" to "Compilar APK", "fr" to "Compiler l'APK", "de" to "APK erstellen", "pt" to "Compilar APK", "ru" to "Собрать APK", "ar" to "إنشاء APK", "zh" to "构建 APK", "ja" to "APKをビルド"),
        "btn_install" to mapOf("en" to "Install", "hi" to "इंस्टॉल करें", "es" to "Instalar", "fr" to "Installer", "de" to "Installieren", "pt" to "Instalar", "ru" to "Установить", "ar" to "تثبيت", "zh" to "安装", "ja" to "インストール"),
        "btn_github_push" to mapOf("en" to "GitHub Push", "hi" to "गिटहब पुश", "es" to "Subir a GitHub", "fr" to "Envoyer vers GitHub", "de" to "Zu GitHub pushen", "pt" to "Enviar para o GitHub", "ru" to "Отправить на GitHub", "ar" to "دفع إلى GitHub", "zh" to "推送到 GitHub", "ja" to "GitHubへプッシュ"),
        "btn_download" to mapOf("en" to "Download", "hi" to "डाउनलोड करें", "es" to "Descargar", "fr" to "Télécharger", "de" to "Herunterladen", "pt" to "Baixar", "ru" to "Скачать", "ar" to "تنزيل", "zh" to "下载", "ja" to "ダウンロード"),
        "btn_get" to mapOf("en" to "Get", "hi" to "प्राप्त करें", "es" to "Obtener", "fr" to "Obtenir", "de" to "Holen", "pt" to "Obter", "ru" to "Получить", "ar" to "جلب", "zh" to "获取", "ja" to "取得"),
        "btn_rename" to mapOf("en" to "Rename", "hi" to "नाम बदलें", "es" to "Renombrar", "fr" to "Renommer", "de" to "Umbenennen", "pt" to "Renomear", "ru" to "Переименовать", "ar" to "إعادة تسمية", "zh" to "重命名", "ja" to "名前変更"),
        "btn_copy" to mapOf("en" to "Copy", "hi" to "कॉपी करें", "es" to "Copiar", "fr" to "Copier", "de" to "Kopieren", "pt" to "Copiar", "ru" to "Копировать", "ar" to "نسخ", "zh" to "复制", "ja" to "コピー"),
        "btn_new_project" to mapOf("en" to "New Project", "hi" to "नया प्रोजेक्ट", "es" to "Nuevo proyecto", "fr" to "Nouveau projet", "de" to "Neues Projekt", "pt" to "Novo projeto", "ru" to "Новый проект", "ar" to "مشروع جديد", "zh" to "新建项目", "ja" to "新規プロジェクト"),
        "btn_new_file" to mapOf("en" to "New File", "hi" to "नई फाइल", "es" to "Nuevo archivo", "fr" to "Nouveau fichier", "de" to "Neue Datei", "pt" to "Novo arquivo", "ru" to "Новый файл", "ar" to "ملف جديد", "zh" to "新建文件", "ja" to "新規ファイル"),
        "btn_new_folder" to mapOf("en" to "New Folder", "hi" to "नया फोल्डर", "es" to "Nueva carpeta", "fr" to "Nouveau dossier", "de" to "Neuer Ordner", "pt" to "Nova pasta", "ru" to "Новая папка", "ar" to "مجلد جديد", "zh" to "新建文件夹", "ja" to "新規フォルダ"),
        "btn_new_screen" to mapOf("en" to "New Screen", "hi" to "नई स्क्रीन", "es" to "Nueva pantalla", "fr" to "Nouvel écran", "de" to "Neuer Bildschirm", "pt" to "Nova tela", "ru" to "Новый экран", "ar" to "شاشة جديدة", "zh" to "新建屏幕", "ja" to "新規画面"),
        "btn_new_script" to mapOf("en" to "New Script", "hi" to "नई स्क्रिप्ट", "es" to "Nuevo script", "fr" to "Nouveau script", "de" to "Neues Skript", "pt" to "Novo script", "ru" to "Новый скрипт", "ar" to "سكربت جديد", "zh" to "新建脚本", "ja" to "新規スクリプト"),
        "btn_yes" to mapOf("en" to "Yes", "hi" to "हाँ", "es" to "Sí", "fr" to "Oui", "de" to "Ja", "pt" to "Sim", "ru" to "Да", "ar" to "نعم", "zh" to "是", "ja" to "はい"),
        "btn_no" to mapOf("en" to "No", "hi" to "नहीं", "es" to "No", "fr" to "Non", "de" to "Nein", "pt" to "Não", "ru" to "Нет", "ar" to "لا", "zh" to "否", "ja" to "いいえ"),
        "btn_ok" to mapOf("en" to "OK", "hi" to "ठीक है", "es" to "Aceptar", "fr" to "OK", "de" to "OK", "pt" to "OK", "ru" to "ОК", "ar" to "موافق", "zh" to "确定", "ja" to "OK"),
        "btn_discard" to mapOf("en" to "Discard", "hi" to "छोड़ें", "es" to "Descartar", "fr" to "Ignorer", "de" to "Verwerfen", "pt" to "Descartar", "ru" to "Отклонить", "ar" to "تجاهل", "zh" to "放弃", "ja" to "破棄"),
        "dlg_delete_title" to mapOf("en" to "Delete?", "hi" to "हटाएं?", "es" to "¿Eliminar?", "fr" to "Supprimer ?", "de" to "Löschen?", "pt" to "Excluir?", "ru" to "Удалить?", "ar" to "حذف؟", "zh" to "删除？", "ja" to "削除しますか？"),
        "dlg_unsaved_title" to mapOf("en" to "Save changes?", "hi" to "बदलाव सेव करें?", "es" to "¿Guardar cambios?", "fr" to "Enregistrer les modifications ?", "de" to "Änderungen speichern?", "pt" to "Salvar alterações?", "ru" to "Сохранить изменения?", "ar" to "حفظ التغييرات؟", "zh" to "保存更改？", "ja" to "変更を保存しますか？"),
        "dlg_unsaved_body" to mapOf("en" to "You have unsaved changes.", "hi" to "आपके कुछ बदलाव सेव नहीं हुए हैं।", "es" to "Tienes cambios sin guardar.", "fr" to "Vous avez des modifications non enregistrées.", "de" to "Du hast ungespeicherte Änderungen.", "pt" to "Você tem alterações não salvas.", "ru" to "У вас есть несохранённые изменения.", "ar" to "لديك تغييرات غير محفوظة.", "zh" to "您有尚未保存的更改。", "ja" to "未保存の変更があります。"),
        "sec_storage" to mapOf("en" to "Storage", "hi" to "स्टोरेज", "es" to "Almacenamiento", "fr" to "Stockage", "de" to "Speicher", "pt" to "Armazenamento", "ru" to "Хранилище", "ar" to "التخزين", "zh" to "存储", "ja" to "ストレージ"),
        "sec_assets" to mapOf("en" to "Assets", "hi" to "एसेट्स", "es" to "Recursos", "fr" to "Ressources", "de" to "Assets", "pt" to "Recursos", "ru" to "Ресурсы", "ar" to "الأصول", "zh" to "资源", "ja" to "アセット"),
        "sec_ai_context" to mapOf("en" to "AI Context", "hi" to "एआई कॉन्टेक्स्ट", "es" to "Contexto de IA", "fr" to "Contexte IA", "de" to "KI-Kontext", "pt" to "Contexto de IA", "ru" to "Контекст ИИ", "ar" to "سياق الذكاء الاصطناعي", "zh" to "AI 上下文", "ja" to "AIコンテキスト"),
        "sec_apk_signing" to mapOf("en" to "APK Signing", "hi" to "एपीके साइनिंग", "es" to "Firma de APK", "fr" to "Signature de l'APK", "de" to "APK-Signierung", "pt" to "Assinatura do APK", "ru" to "Подпись APK", "ar" to "توقيع APK", "zh" to "APK 签名", "ja" to "APK署名"),
        "sec_about" to mapOf("en" to "About", "hi" to "जानकारी", "es" to "Acerca de", "fr" to "À propos", "de" to "Über", "pt" to "Sobre", "ru" to "О программе", "ar" to "حول", "zh" to "关于", "ja" to "概要"),
        "sec_language" to mapOf("en" to "Language", "hi" to "भाषा", "es" to "Idioma", "fr" to "Langue", "de" to "Sprache", "pt" to "Idioma", "ru" to "Язык", "ar" to "اللغة", "zh" to "语言", "ja" to "言語"),
        "toast_saved" to mapOf("en" to "Saved", "hi" to "सेव हो गया", "es" to "Guardado", "fr" to "Enregistré", "de" to "Gespeichert", "pt" to "Salvo", "ru" to "Сохранено", "ar" to "تم الحفظ", "zh" to "已保存", "ja" to "保存しました"),
        "toast_import_ok" to mapOf("en" to "Imported", "hi" to "इम्पोर्ट हो गया", "es" to "Importado", "fr" to "Importé", "de" to "Importiert", "pt" to "Importado", "ru" to "Импортировано", "ar" to "تم الاستيراد", "zh" to "已导入", "ja" to "インポートしました"),
        "toast_import_fail" to mapOf("en" to "Import failed", "hi" to "इम्पोर्ट विफल", "es" to "Error al importar", "fr" to "Échec de l'importation", "de" to "Import fehlgeschlagen", "pt" to "Falha ao importar", "ru" to "Ошибка импорта", "ar" to "فشل الاستيراد", "zh" to "导入失败", "ja" to "インポートに失敗しました"),
        "label_project" to mapOf("en" to "Project", "hi" to "प्रोजेक्ट", "es" to "Proyecto", "fr" to "Projet", "de" to "Projekt", "pt" to "Projeto", "ru" to "Проект", "ar" to "المشروع", "zh" to "项目", "ja" to "プロジェクト"),
        "label_screen" to mapOf("en" to "Screen", "hi" to "स्क्रीन", "es" to "Pantalla", "fr" to "Écran", "de" to "Bildschirm", "pt" to "Tela", "ru" to "Экран", "ar" to "الشاشة", "zh" to "屏幕", "ja" to "画面"),
        "save_to" to mapOf("en" to "Save to…", "hi" to "यहां सेव करें…", "es" to "Guardar en…", "fr" to "Enregistrer sous…", "de" to "Speichern unter…", "pt" to "Salvar em…", "ru" to "Сохранить в…", "ar" to "حفظ في…", "zh" to "保存到…", "ja" to "保存先…"),
        "app_settings" to mapOf("en" to "App Settings", "hi" to "ऐप सेटिंग्स", "es" to "Ajustes de la app", "fr" to "Paramètres de l'application", "de" to "App-Einstellungen", "pt" to "Configurações do app", "ru" to "Настройки приложения", "ar" to "إعدادات التطبيق", "zh" to "应用设置", "ja" to "アプリ設定"),
        "tab_preview" to mapOf("en" to "Preview", "hi" to "प्रीव्यू", "es" to "Vista previa", "fr" to "Aperçu", "de" to "Vorschau", "pt" to "Visualização", "ru" to "Просмотр", "ar" to "معاينة", "zh" to "预览", "ja" to "プレビュー"),
        "tab_tree" to mapOf("en" to "Tree", "hi" to "ट्री", "es" to "Árbol", "fr" to "Arborescence", "de" to "Baum", "pt" to "Árvore", "ru" to "Дерево", "ar" to "الشجرة", "zh" to "树状图", "ja" to "ツリー"),
        "tab_props" to mapOf("en" to "Properties", "hi" to "प्रॉपर्टीज़", "es" to "Propiedades", "fr" to "Propriétés", "de" to "Eigenschaften", "pt" to "Propriedades", "ru" to "Свойства", "ar" to "الخصائص", "zh" to "属性", "ja" to "プロパティ"),
        "tab_scripts" to mapOf("en" to "Scripts", "hi" to "स्क्रिप्ट्स", "es" to "Scripts", "fr" to "Scripts", "de" to "Skripte", "pt" to "Scripts", "ru" to "Скрипты", "ar" to "السكربتات", "zh" to "脚本", "ja" to "スクリプト"),
    )
}
