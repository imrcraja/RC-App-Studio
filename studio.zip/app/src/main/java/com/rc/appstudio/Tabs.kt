package com.rc.appstudio

import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Req(
    val url: String?,
    val fileName: String,
    val title: String,
    val builtin: String?,
    val size: Long = -1L
)

class FileActions(val save: (File) -> Unit, val share: (File) -> Unit)

fun shareFile(ctx: Context, f: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val i = Intent(Intent.ACTION_SEND)
        i.type = "application/octet-stream"
        i.putExtra(Intent.EXTRA_STREAM, uri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val chooser = Intent.createChooser(i, f.name)
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(chooser)
    } catch (e: Exception) {
        toast(ctx, "Share failed: " + e.message)
    }
}

@Composable
fun rememberFileActions(): FileActions {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var target by remember { mutableStateOf<File?>(null) }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        val f = target
        if (uri != null && f != null) {
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        val os = ctx.contentResolver.openOutputStream(uri)
                            ?: throw IOException("Could not save")
                        os.use { o -> f.inputStream().use { it.copyTo(o) } }
                    }
                    toast(ctx, t("toast_saved"))
                } catch (e: Exception) {
                    toast(ctx, "Save failed: " + e.message)
                }
            }
        }
    }
    return remember {
        FileActions(
            { f ->
                target = f
                launcher.launch(f.name)
            },
            { f -> shareFile(ctx, f) }
        )
    }
}

@Composable
fun FileRow(
    f: File,
    subtitle: String,
    actions: FileActions,
    onDelete: () -> Unit,
    extra: @Composable RowScope.() -> Unit = {}
) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 5.dp)
            .background(RcCard, RoundedCornerShape(10.dp)).padding(10.dp)
    ) {
        Text(
            f.name, color = Color.White, fontSize = 14.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(subtitle, color = RcMuted, fontSize = 11.sp)
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            TextButton(onClick = { actions.save(f) }) { Text(t("save_to")) }
            TextButton(onClick = { actions.share(f) }) { Text(t("btn_share")) }
            extra()
            TextButton(onClick = onDelete) { Text(t("btn_delete")) }
        }
    }
}

@Composable
fun DownloadConfirmDialog(req: Req, onOk: (Boolean) -> Unit, onNo: () -> Unit) {
    var skip by remember { mutableStateOf(false) }
    val mb = if (req.size > 0) String.format(Locale.US, "%.1f MB", req.size / 1048576.0) else "size unknown"
    AlertDialog(
        onDismissRequest = onNo,
        title = { Text("Download this asset?") },
        text = {
            Column {
                Text(req.title)
                Spacer(Modifier.height(6.dp))
                Text("This will use your data: $mb", fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = skip, onCheckedChange = { skip = it })
                    Text("Don't show this again")
                }
            }
        },
        confirmButton = { TextButton(onClick = { onOk(skip) }) { Text(t("btn_download")) } },
        dismissButton = { TextButton(onClick = onNo) { Text(t("btn_cancel")) } }
    )
}

fun dateLabel(day: String): String {
    val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val today = f.format(Date())
    val cal = Calendar.getInstance()
    cal.add(Calendar.DAY_OF_YEAR, -1)
    val yest = f.format(cal.time)
    return when (day) {
        today -> "Today"
        yest -> "Yesterday"
        else -> day
    }
}

/* ------------------------- Assets ------------------------- */

@Composable
fun ColumnScope.AssetsTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val actions = rememberFileActions()
    var tick by remember { mutableIntStateOf(0) }
    val recs = remember(tick) { Assets.records(ctx) }
    val pend = remember(tick) { Assets.pending(ctx) }
    val online = remember(tick) { Assets.isOnline(ctx) }
    var busy by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf<Req?>(null) }
    var showUrl by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Assets.Rec?>(null) }

    suspend fun offlineFallback(req: Req) {
        if (Prefs.deviceAssets(ctx)) {
            val ok = withContext(Dispatchers.IO) {
                try {
                    Assets.copyFromDevice(ctx, req.fileName, req.title)
                } catch (e: Exception) {
                    false
                }
            }
            if (ok) {
                toast(ctx, "Found it on your device")
                return
            }
        }
        val b = req.builtin
        if (b != null) {
            withContext(Dispatchers.IO) { Assets.fromBuiltin(ctx, b, req.fileName, req.title) }
            val u = req.url
            if (u != null) Assets.addPending(ctx, Assets.Pending(u, req.fileName, req.title, b))
            toast(ctx, "Made a built-in version. The real one will download once you're online.")
        } else {
            toast(ctx, "No internet, and no built-in version available")
        }
    }

    suspend fun doDownload(req: Req) {
        val u = req.url ?: return
        busy = "Downloading: " + req.fileName
        try {
            withContext(Dispatchers.IO) { Assets.download(ctx, u, req.fileName, req.title) }
            toast(ctx, "Download complete")
        } catch (e: Exception) {
            toast(ctx, "Download failed: " + e.message)
            offlineFallback(req)
        }
        busy = ""
        tick++
    }

    fun start(req: Req) {
        scope.launch {
            val u = req.url
            if (u != null && Assets.isOnline(ctx)) {
                busy = "Checking size..."
                val size = withContext(Dispatchers.IO) {
                    try {
                        Assets.headSize(u)
                    } catch (e: Exception) {
                        -1L
                    }
                }
                busy = ""
                if (Prefs.skipConfirm(ctx)) doDownload(req) else confirm = req.copy(size = size)
            } else {
                offlineFallback(req)
                tick++
            }
        }
    }

    LaunchedEffect(Unit) {
        if (Prefs.skipConfirm(ctx) && Assets.isOnline(ctx)) {
            for (p in Assets.pending(ctx)) {
                doDownload(Req(p.url, p.fileName, p.title, p.builtin))
            }
        }
    }

    Text(
        if (online) "● Online" else "● Offline",
        color = if (online) Color(0xFF4CAF50) else Color(0xFFFF7043), fontSize = 12.sp
    )
    if (busy.isNotEmpty()) Text(busy, color = RcMuted, fontSize = 12.sp)

    LazyColumn(Modifier.weight(1f)) {
        item {
            Text("Catalog", color = RcAccent, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        }
        items(Assets.catalog) { e ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(e.title, color = Color.White, fontSize = 14.sp)
                    Text(e.fileName, color = RcMuted, fontSize = 11.sp)
                }
                MdeButton(t("btn_get"), { start(Req(e.url, e.fileName, e.title, e.builtin)) })
            }
        }
        item {
            Spacer(Modifier.height(6.dp))
            MdeButton("Download from URL", { showUrl = true })
        }
        if (pend.isNotEmpty()) {
            item {
                Text(
                    "Pending (will download once online)", color = RcAccent,
                    fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp)
                )
            }
            items(pend) { p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(p.title, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    MdeButton(t("btn_download"), { start(Req(p.url, p.fileName, p.title, p.builtin)) })
                }
            }
        }
        item {
            Text(
                "Downloaded assets", color = RcAccent, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 12.dp)
            )
        }
        if (recs.isEmpty()) {
            item { Text("Nothing downloaded yet.", color = RcMuted, fontSize = 12.sp) }
        }
        val groups = recs.groupBy { it.path.substringBefore('/') }
        groups.forEach { (day, list) ->
            item(key = "h$day") {
                Text(dateLabel(day), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            }
            items(list, key = { it.path }) { r ->
                val f = File(Assets.dir(ctx), r.path)
                FileRow(f, r.title + " • " + r.source + " • " + Fs.sizeText(f), actions, onDelete = { toDelete = r })
            }
        }
    }

    val c = confirm
    if (c != null) {
        DownloadConfirmDialog(c, onOk = { skip ->
            if (skip) Prefs.setSkipConfirm(ctx, true)
            confirm = null
            scope.launch { doDownload(c) }
        }, onNo = { confirm = null })
    }
    if (showUrl) {
        InputDialog("Direct download URL", "https://", onOk = { u ->
            showUrl = false
            if (u.startsWith("http")) {
                val name = u.substringBefore('?').substringAfterLast('/').ifBlank { "download.bin" }
                start(Req(u, name, name, null))
            }
        }, onCancel = { showUrl = false })
    }
    val del = toDelete
    if (del != null) {
        ConfirmDialog(t("dlg_delete_title"), "Delete this asset?", onYes = {
            Assets.delete(ctx, del)
            toDelete = null
            tick++
        }, onNo = { toDelete = null })
    }
}

/* ------------------------- Downloads ------------------------- */

@Composable
fun ColumnScope.DownloadsTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val actions = rememberFileActions()
    var tick by remember { mutableIntStateOf(0) }
    val files = remember(tick) {
        (Fs.downloads(ctx).listFiles()?.toList() ?: emptyList())
            .filter { it.isFile }
            .sortedWith(
                compareByDescending<File> { it.name == "AI_CONTEXT.md" }
                    .thenByDescending { it.lastModified() }
            )
    }
    var toDelete by remember { mutableStateOf<File?>(null) }
    val cloud = remember { Cloud.load(ctx) }
    val cloudOn = Cloud.ready(cloud)
    val fmt = remember { SimpleDateFormat("dd MMM yyyy HH:mm", Locale.US) }

    Text(
        "This app's Downloads folder. Save any file to any folder, or Share it to any app. " +
            "Give AI_CONTEXT.md to any AI and it will understand the whole setup.",
        color = RcMuted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp)
    )
    if (files.isEmpty()) Text("Nothing here yet.", color = RcMuted)
    LazyColumn(Modifier.weight(1f)) {
        items(files, key = { it.name }) { f ->
            FileRow(
                f, Fs.sizeText(f) + " • " + fmt.format(Date(f.lastModified())), actions,
                onDelete = { toDelete = f },
                extra = {
                    val n = f.name.lowercase()
                    if (n.endsWith(".rc") || n.endsWith(".zip")) {
                        TextButton(onClick = {
                            scope.launch {
                                try {
                                    val d = withContext(Dispatchers.IO) {
                                        f.inputStream().use { Fs.importStream(ctx, f.name, it) }
                                    }
                                    toast(ctx, "Project imported: " + d.name)
                                } catch (e: Exception) {
                                    toast(ctx, "Import failed: " + e.message)
                                }
                            }
                        }) { Text(t("btn_import")) }
                    }
                    if (n.endsWith(".apk")) {
                        TextButton(onClick = { ApkBuilder.install(ctx, f) }) { Text(t("btn_install")) }
                    }
                    if (cloudOn) {
                        TextButton(onClick = {
                            scope.launch {
                                try {
                                    withContext(Dispatchers.IO) { Cloud.upload(cloud, f, f.name) }
                                    toast(ctx, "Uploaded to cloud")
                                } catch (e: Exception) {
                                    toast(ctx, "Cloud upload failed: " + e.message)
                                }
                            }
                        }) { Text("Cloud ↑") }
                    }
                }
            )
        }
    }
    val del = toDelete
    if (del != null) {
        ConfirmDialog(t("dlg_delete_title"), "Delete '" + del.name + "'?", onYes = {
            del.delete()
            toDelete = null
            tick++
        }, onNo = { toDelete = null })
    }
}
