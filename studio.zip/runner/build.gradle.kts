plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rc.runner"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.rc.runner"
        minSdk = 24
        targetSdk = 29
        versionCode = 1
        versionName = "RC_VERSION"
    }
    buildTypes {
        getByName("debug") { isDebuggable = false }
    }
    sourceSets {
        getByName("main") { java.srcDir("../shared") }
    }
    lint { abortOnError = false; checkReleaseBuilds = false }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
