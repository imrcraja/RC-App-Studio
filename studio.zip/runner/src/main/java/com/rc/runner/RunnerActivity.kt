package com.rc.runner

import android.content.Intent
import android.content.pm.ResolveInfo
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import com.rc.lang.Interp
import com.rc.lang.RcHost
import org.json.JSONObject
import java.io.File

/** RC Runner: app.rc.json padhkar UI banata hai aur RC code chalata hai. */
class RunnerActivity : ComponentActivity(), RcHost {
    private var doc = JSONObject()
    private var scripts = JSONObject()
    private val views = HashMap<String, View>()
    private val stack = ArrayList<String>()
    private val interp = Interp(this)
    private var primary = Color.parseColor("#7C4DFF")

    // "importer" component state (file -> choose an app to send it to, e.g. Minecraft)
    private var pendingPrimaryPkg = ""
    private var pendingPrimaryLabel = ""
    private var pendingStatus: TextView? = null
    private var pendingTargets: LinearLayout? = null
    private val pickLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onFilePicked(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val txt = assets.open("app.rc.json").bufferedReader().use { it.readText() }
            doc = JSONObject(txt)
            scripts = doc.optJSONObject("scripts") ?: JSONObject()
            val app = doc.optJSONObject("app")
            if (app != null) primary = col(app.optString("primary"), primary)
            val screens = doc.optJSONArray("screens")
            if (screens == null || screens.length() == 0) {
                setContentView(msg("Is app me abhi koi screen nahi hai."))
                return
            }
            val first = doc.optString("start", screens.getJSONObject(0).optString("id"))
            screen(first)
        } catch (e: Exception) {
            setContentView(msg("Error: " + e.message))
        }
    }

    private fun msg(t: String): View {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.WHITE)
        tv.setBackgroundColor(Color.parseColor("#000216"))
        tv.setPadding(dp(16), dp(48), dp(16), dp(16))
        return tv
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun col(s: String?, def: Int): Int {
        if (s.isNullOrBlank()) return def
        return try {
            Color.parseColor(s.trim())
        } catch (e: Exception) {
            def
        }
    }

    private fun findScreen(id: String): JSONObject? {
        val arr = doc.optJSONArray("screens") ?: return null
        for (i in 0 until arr.length()) {
            val s = arr.getJSONObject(i)
            if (s.optString("id") == id) return s
        }
        return null
    }

    private fun render(id: String) {
        val sc = findScreen(id)
        if (sc == null) {
            toast("Screen nahi mili: $id")
            return
        }
        views.clear()
        val bg = col(sc.optString("bg"), Color.parseColor("#000216"))
        val lum = (Color.red(bg) * 299 + Color.green(bg) * 587 + Color.blue(bg) * 114) / 1000
        val defText = if (lum < 128) Color.WHITE else Color.BLACK
        val root = sc.optJSONObject("root")
        val body: View = if (root != null) build(root, defText) else View(this)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        scroll.isFillViewport = true
        scroll.addView(body, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)
    }

    private fun size(v: String?, def: Int): Int {
        if (v == null || v.isBlank()) return def
        return when (v.trim().lowercase()) {
            "match" -> ViewGroup.LayoutParams.MATCH_PARENT
            "wrap" -> ViewGroup.LayoutParams.WRAP_CONTENT
            else -> v.trim().toIntOrNull()?.let { dp(it) } ?: def
        }
    }

    private fun build(n: JSONObject, defText: Int): View {
        val type = n.optString("type")
        val id = n.optString("id")
        val p = n.optJSONObject("props") ?: JSONObject()
        val v: View
        when (type) {
            "row", "column" -> {
                val ll = LinearLayout(this)
                ll.orientation = if (type == "row") LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
                if (p.optString("gravity") == "center") ll.gravity = Gravity.CENTER
                val kids = n.optJSONArray("kids")
                if (kids != null) {
                    for (i in 0 until kids.length()) ll.addView(build(kids.getJSONObject(i), defText))
                }
                v = ll
            }
            "text" -> {
                val tv = TextView(this)
                tv.text = p.optString("text")
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, p.optString("size", "16").toFloatOrNull() ?: 16f)
                tv.setTextColor(col(p.optString("color"), defText))
                if (p.optString("bold") == "true") tv.setTypeface(null, Typeface.BOLD)
                v = tv
            }
            "button" -> {
                val b = Button(this)
                b.text = p.optString("text")
                b.setTextSize(TypedValue.COMPLEX_UNIT_SP, p.optString("size", "14").toFloatOrNull() ?: 14f)
                b.setTextColor(col(p.optString("color"), Color.WHITE))
                b.backgroundTintList = ColorStateList.valueOf(col(p.optString("bg"), primary))
                v = b
            }
            "input" -> {
                val et = EditText(this)
                et.hint = p.optString("hint")
                et.setText(p.optString("text"))
                et.setTextSize(TypedValue.COMPLEX_UNIT_SP, p.optString("size", "16").toFloatOrNull() ?: 16f)
                et.setTextColor(col(p.optString("color"), defText))
                et.setHintTextColor(Color.GRAY)
                et.inputType = InputType.TYPE_CLASS_TEXT
                v = et
            }
            "image" -> {
                val iv = ImageView(this)
                try {
                    val name = p.optString("src").removePrefix("assets/")
                    assets.open(name).use { iv.setImageBitmap(BitmapFactory.decodeStream(it)) }
                } catch (e: Exception) {
                    // image na mile to khali rahega
                }
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                v = iv
            }
            "importer" -> {
                val ll = LinearLayout(this)
                ll.orientation = LinearLayout.VERTICAL
                val btn = Button(this)
                btn.text = p.optString("button", "Choose file to import")
                btn.setTextColor(Color.WHITE)
                btn.backgroundTintList = ColorStateList.valueOf(col(p.optString("bg"), primary))
                val status = TextView(this)
                status.setTextColor(defText)
                status.textSize = 12f
                status.setPadding(0, dp(8), 0, dp(4))
                status.visibility = View.GONE
                val targets = LinearLayout(this)
                targets.orientation = LinearLayout.VERTICAL
                btn.setOnClickListener {
                    pendingPrimaryPkg = p.optString("primaryPackage", "com.mojang.minecraftpe")
                    pendingPrimaryLabel = p.optString("primaryLabel", "Minecraft (Bedrock)")
                    pendingStatus = status
                    pendingTargets = targets
                    try {
                        pickLauncher.launch(arrayOf("*/*"))
                    } catch (e: Exception) {
                        toast("Could not open file picker")
                    }
                }
                ll.addView(btn)
                ll.addView(status)
                ll.addView(targets)
                v = ll
            }
            else -> v = View(this)
        }

        if (type != "button" && type != "input" && type != "text" && p.optString("bg").isNotBlank()) {
            v.setBackgroundColor(col(p.optString("bg"), Color.TRANSPARENT))
        } else if ((type == "text") && p.optString("bg").isNotBlank()) {
            v.setBackgroundColor(col(p.optString("bg"), Color.TRANSPARENT))
        }
        val defW = if (type == "button" || type == "row" || type == "column" || type == "input") ViewGroup.LayoutParams.MATCH_PARENT else ViewGroup.LayoutParams.WRAP_CONTENT
        val w = size(p.optString("w"), defW)
        val h = size(p.optString("h"), ViewGroup.LayoutParams.WRAP_CONTENT)
        val weight = p.optString("weight").toFloatOrNull() ?: 0f
        val lp = LinearLayout.LayoutParams(w, h, weight)
        val m = p.optString("margin").toIntOrNull() ?: 0
        lp.setMargins(dp(m), dp(m), dp(m), dp(m))
        v.layoutParams = lp
        val pad = p.optString("padding").toIntOrNull()
        if (pad != null) v.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        if (p.optString("visible") == "false") v.visibility = View.GONE

        val click = p.optString("onClick")
        if (click.isNotBlank()) {
            v.setOnClickListener { runScript(click) }
        }
        if (id.isNotBlank()) views[id] = v
        return v
    }

    /* ---------- importer: pick a file, then choose which app to send it to ---------- */

    private fun queryDisplayName(uri: Uri): String? {
        var name: String? = null
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i)
            }
        } catch (e: Exception) {
            // agar naam na mile to default use karenge
        }
        return name
    }

    private fun mimeForName(name: String): String {
        val n = name.lowercase()
        return when {
            n.endsWith(".mcpack") -> "application/mcpack"
            n.endsWith(".mcaddon") -> "application/mcaddon"
            n.endsWith(".mcworld") -> "application/mcworld"
            n.endsWith(".mctemplate") -> "application/mctemplate"
            n.endsWith(".zip") -> "application/zip"
            else -> "application/octet-stream"
        }
    }

    private fun addTargetButton(container: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this)
        b.text = label
        b.setTextColor(Color.WHITE)
        b.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(6)
        b.layoutParams = lp
        container.addView(b)
    }

    private fun onFilePicked(uri: Uri) {
        val status = pendingStatus ?: return
        val targets = pendingTargets ?: return
        try {
            val name = queryDisplayName(uri) ?: ("file_" + System.currentTimeMillis())
            val cacheFile = File(cacheDir, "import_" + System.currentTimeMillis() + "_" + name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
            contentResolver.openInputStream(uri)?.use { ins -> cacheFile.outputStream().use { ins.copyTo(it) } }
                ?: throw Exception("Could not read the file")
            val mime = mimeForName(name)
            val fileUri = FileProvider.getUriForFile(this, packageName + ".files", cacheFile)

            status.text = "Selected: " + name
            status.visibility = View.VISIBLE
            targets.removeAllViews()

            fun openWith(pkg: String?) {
                try {
                    val i = Intent(Intent.ACTION_VIEW)
                    i.setDataAndType(fileUri, mime)
                    if (pkg != null) i.setPackage(pkg)
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } catch (e: Exception) {
                    toast("Could not open that app")
                }
            }

            val pm = packageManager
            val primaryInstalled = try {
                pm.getPackageInfo(pendingPrimaryPkg, 0)
                true
            } catch (e: Exception) {
                false
            }
            if (primaryInstalled) {
                addTargetButton(targets, pendingPrimaryLabel) { openWith(pendingPrimaryPkg) }
            } else {
                addTargetButton(targets, pendingPrimaryLabel + " (not installed)") {
                    toast(pendingPrimaryLabel + " is not installed on this device")
                }
            }

            val seen = HashSet<String>()
            seen.add(pendingPrimaryPkg)
            seen.add(packageName)
            val probe = Intent(Intent.ACTION_VIEW)
            probe.setDataAndType(fileUri, mime)
            val list: List<ResolveInfo> = try {
                pm.queryIntentActivities(probe, 0)
            } catch (e: Exception) {
                emptyList()
            }
            var extra = 0
            for (ri in list) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (pkg in seen) continue
                seen.add(pkg)
                val label = try {
                    ri.loadLabel(pm).toString()
                } catch (e: Exception) {
                    pkg
                }
                addTargetButton(targets, label) { openWith(pkg) }
                extra++
            }
            if (extra == 0) {
                val info = TextView(this)
                info.text = "No other apps found that can open this file."
                info.setTextColor(Color.GRAY)
                info.textSize = 11f
                info.setPadding(0, dp(4), 0, 0)
                targets.addView(info)
            }
        } catch (e: Exception) {
            status.text = "Import failed: " + e.message
            status.visibility = View.VISIBLE
        }
    }

    private fun runScript(name: String) {
        val code = scripts.optString(name, "")
        if (code.isEmpty()) {
            toast("Script nahi mili: $name")
            return
        }
        try {
            interp.run(code)
        } catch (e: Exception) {
            toast("RC error: " + e.message)
        }
    }

    /* ---------- RcHost ---------- */
    override fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    override fun setText(id: String, v: String) {
        val t = views[id]
        if (t is TextView) t.text = v
    }

    override fun getText(id: String): String {
        val t = views[id]
        return if (t is TextView) t.text.toString() else ""
    }

    override fun setVisible(id: String, v: Boolean) {
        views[id]?.visibility = if (v) View.VISIBLE else View.GONE
    }

    override fun setBg(id: String, hex: String) {
        val v = views[id] ?: return
        try {
            v.setBackgroundColor(col(hex, Color.TRANSPARENT))
        } catch (e: Exception) {
            // galat color ho to kuch nahi karte
        }
    }

    override fun copy(text: String) {
        try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("rc", text))
        } catch (e: Exception) {
            // clipboard fail ho to silently ignore
        }
    }

    override fun screen(id: String) {
        stack.add(id)
        render(id)
    }

    override fun back() {
        onBackPressed()
    }

    override fun url(u: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
        } catch (e: Exception) {
            toast("Link nahi khula")
        }
    }

    override fun script(name: String): String? {
        val s = scripts.optString(name, "")
        return if (s.isEmpty()) null else s
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (stack.size > 1) {
            stack.removeAt(stack.size - 1)
            render(stack[stack.size - 1])
        } else {
            super.onBackPressed()
        }
    }
}
