package com.rc.runner

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.rc.lang.Interp
import com.rc.lang.RcHost
import org.json.JSONObject

/** RC Runner: app.rc.json padhkar UI banata hai aur RC code chalata hai. */
class RunnerActivity : Activity(), RcHost {
    private var doc = JSONObject()
    private var scripts = JSONObject()
    private val views = HashMap<String, View>()
    private val stack = ArrayList<String>()
    private val interp = Interp(this)
    private var primary = Color.parseColor("#7C4DFF")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val txt = assets.open("app.rc.json").bufferedReader().use { it.readText() }
            doc = JSONObject(txt)
            scripts = doc.optJSONObject("scripts") ?: JSONObject()
            val app = doc.optJSONObject("app")
            if (app != null) primary = col(app.optString("primary"), primary)
            val screens = doc.optJSONArray("screens")
            if (screens == null || screens.length() == 0) {
                setContentView(msg("Is app me abhi koi screen nahi hai."))
                return
            }
            val first = doc.optString("start", screens.getJSONObject(0).optString("id"))
            screen(first)
        } catch (e: Exception) {
            setContentView(msg("Error: " + e.message))
        }
    }

    private fun msg(t: String): View {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.WHITE)
        tv.setBackgroundColor(Color.parseColor("#000216"))
        tv.setPadding(dp(16), dp(48), dp(16), dp(16))
        return tv
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun col(s: String?, def: Int): Int {
        if (s.isNullOrBlank()) return def
        return try {
            Color.parseColor(s.trim())
        } catch (e: Exception) {
            def
        }
    }

    private fun findScreen(id: String): JSONObject? {
        val arr = doc.optJSONArray("screens") ?: return null
        for (i in 0 until arr.length()) {
            val s = arr.getJSONObject(i)
            if (s.optString("id") == id) return s
        }
        return null
    }

    private fun render(id: String) {
        val sc = findScreen(id)
        if (sc == null) {
            toast("Screen nahi mili: $id")
            return
        }
        views.clear()
        val bg = col(sc.optString("bg"), Color.parseColor("#000216"))
        val lum = (Color.red(bg) * 299 + Color.green(bg) * 587 + Color.blue(bg) * 114) / 1000
        val defText = if (lum < 128) Color.WHITE else Color.BLACK
        val root = sc.optJSONObject("root")
        val body: View = if (root != null) build(root, defText) else View(this)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        scroll.isFillViewport = true
        scroll.addView(body, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)
    }

    private fun size(v: String?, def: Int): Int {
        if (v == null || v.isBlank()) return def
        return when (v.trim().lowercase()) {
            "match" -> ViewGroup.LayoutParams.MATCH_PARENT
            "wrap" -> ViewGroup.LayoutParams.WRAP_CONTENT
            else -> v.trim().toIntOrNull()?.let { dp(it) } ?: def
        }
    }

    private fun build(n: JSONObject, defText: Int): View {
        val type = n.optString("type")
        val id = n.optString("id")
        val p = n.optJSONObject("props") ?: JSONObject()
        val v: View
        when (type) {
            "row", "column" -> {
                val ll = LinearLayout(this)
                ll.orientation = if (type == "row") LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
                if (p.optString("gravity") == "center") ll.gravity = Gravity.CENTER
                val kids = n.optJSONArray("kids")
                if (kids != null) {
                    for (i in 0 until kids.length()) ll.addView(build(kids.getJSONObject(i), defText))
                }
                v = ll
            }
            "text" -> {
                val tv = TextView(this)
                tv.text = p.optString("text")
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, p.optString("size", "16").toFloatOrNull() ?: 16f)
                tv.setTextColor(col(p.optString("color"), defText))
                if (p.optString("bold") == "true") tv.setTypeface(null, Typeface.BOLD)
                v = tv
            }
            "button" -> {
                val b = Button(this)
                b.text = p.optString("text")
                b.setTextSize(TypedValue.COMPLEX_UNIT_SP, p.optString("size", "14").toFloatOrNull() ?: 14f)
                b.setTextColor(col(p.optString("color"), Color.WHITE))
                b.backgroundTintList = ColorStateList.valueOf(col(p.optString("bg"), primary))
                v = b
            }
            "input" -> {
                val et = EditText(this)
                et.hint = p.optString("hint")
                et.setText(p.optString("text"))
                et.setTextSize(TypedValue.COMPLEX_UNIT_SP, p.optString("size", "16").toFloatOrNull() ?: 16f)
                et.setTextColor(col(p.optString("color"), defText))
                et.setHintTextColor(Color.GRAY)
                et.inputType = InputType.TYPE_CLASS_TEXT
                v = et
            }
            "image" -> {
                val iv = ImageView(this)
                try {
                    val name = p.optString("src").removePrefix("assets/")
                    assets.open(name).use { iv.setImageBitmap(BitmapFactory.decodeStream(it)) }
                } catch (e: Exception) {
                    // image na mile to khali rahega
                }
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                v = iv
            }
            else -> v = View(this)
        }

        if (type != "button" && type != "input" && type != "text" && p.optString("bg").isNotBlank()) {
            v.setBackgroundColor(col(p.optString("bg"), Color.TRANSPARENT))
        } else if ((type == "text") && p.optString("bg").isNotBlank()) {
            v.setBackgroundColor(col(p.optString("bg"), Color.TRANSPARENT))
        }
        val defW = if (type == "button" || type == "row" || type == "column" || type == "input") ViewGroup.LayoutParams.MATCH_PARENT else ViewGroup.LayoutParams.WRAP_CONTENT
        val w = size(p.optString("w"), defW)
        val h = size(p.optString("h"), ViewGroup.LayoutParams.WRAP_CONTENT)
        val weight = p.optString("weight").toFloatOrNull() ?: 0f
        val lp = LinearLayout.LayoutParams(w, h, weight)
        val m = p.optString("margin").toIntOrNull() ?: 0
        lp.setMargins(dp(m), dp(m), dp(m), dp(m))
        v.layoutParams = lp
        val pad = p.optString("padding").toIntOrNull()
        if (pad != null) v.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        if (p.optString("visible") == "false") v.visibility = View.GONE

        val click = p.optString("onClick")
        if (click.isNotBlank()) {
            v.setOnClickListener { runScript(click) }
        }
        if (id.isNotBlank()) views[id] = v
        return v
    }

    private fun runScript(name: String) {
        val code = scripts.optString(name, "")
        if (code.isEmpty()) {
            toast("Script nahi mili: $name")
            return
        }
        try {
            interp.run(code)
        } catch (e: Exception) {
            toast("RC error: " + e.message)
        }
    }

    /* ---------- RcHost ---------- */
    override fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    override fun setText(id: String, v: String) {
        val t = views[id]
        if (t is TextView) t.text = v
    }

    override fun getText(id: String): String {
        val t = views[id]
        return if (t is TextView) t.text.toString() else ""
    }

    override fun setVisible(id: String, v: Boolean) {
        views[id]?.visibility = if (v) View.VISIBLE else View.GONE
    }

    override fun screen(id: String) {
        stack.add(id)
        render(id)
    }

    override fun back() {
        onBackPressed()
    }

    override fun url(u: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
        } catch (e: Exception) {
            toast("Link nahi khula")
        }
    }

    override fun script(name: String): String? {
        val s = scripts.optString(name, "")
        return if (s.isEmpty()) null else s
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (stack.size > 1) {
            stack.removeAt(stack.size - 1)
            render(stack[stack.size - 1])
        } else {
            super.onBackPressed()
        }
    }
}
