package com.rc.lang

/** RC code: chhoti, line-based language. Studio (check) aur Runner (chalane) dono yahi use karte hain. */
interface RcHost {
    fun toast(s: String)
    fun setText(id: String, v: String)
    fun getText(id: String): String
    fun setVisible(id: String, v: Boolean)
    fun setBg(id: String, hex: String)
    fun copy(text: String)
    fun screen(id: String)
    fun back()
    fun url(u: String)
    fun script(name: String): String?
}

class RcError(msg: String, val line: Int) : Exception("Line $line: $msg")

sealed class Stmt {
    abstract val line: Int
}

class Simple(val cmd: String, val args: String, override val line: Int) : Stmt()
class IfStmt(val cond: String, val thenL: List<Stmt>, val elseL: List<Stmt>, override val line: Int) : Stmt()

object RcLang {
    val KNOWN = setOf(
        "set", "toast", "text", "show", "hide", "bg", "copy",
        "encode", "decode", "screen", "back", "url", "run"
    )

    private class Frame(val cond: String, val line: Int) {
        val thenL = ArrayList<Stmt>()
        val elseL = ArrayList<Stmt>()
        var inElse = false
    }

    /** null = theek hai, warna error ka message */
    fun check(code: String): String? {
        return try {
            parse(code)
            null
        } catch (e: RcError) {
            e.message
        }
    }

    fun parse(code: String): List<Stmt> {
        val root = ArrayList<Stmt>()
        val stack = ArrayList<Frame>()
        fun cur(): MutableList<Stmt> {
            if (stack.isEmpty()) return root
            val f = stack[stack.size - 1]
            return if (f.inElse) f.elseL else f.thenL
        }
        val lines = code.split("\n")
        for (idx in lines.indices) {
            val ln = idx + 1
            val t = lines[idx].trim()
            if (t.isEmpty() || t.startsWith("#")) continue
            val cmd = t.substringBefore(' ').lowercase()
            val rest = t.substringAfter(' ', "").trim()
            when (cmd) {
                "if" -> {
                    if (rest.isEmpty()) throw RcError("if ke baad condition likho", ln)
                    stack.add(Frame(rest, ln))
                }
                "else" -> {
                    if (stack.isEmpty()) throw RcError("else bina if ke", ln)
                    val f = stack[stack.size - 1]
                    if (f.inElse) throw RcError("ek if me do else nahi ho sakte", ln)
                    f.inElse = true
                }
                "end" -> {
                    if (stack.isEmpty()) throw RcError("end bina if ke", ln)
                    val f = stack.removeAt(stack.size - 1)
                    cur().add(IfStmt(f.cond, f.thenL, f.elseL, f.line))
                }
                else -> {
                    if (cmd !in KNOWN) throw RcError("'$cmd' command nahi pata", ln)
                    val needsEq = cmd == "set" || cmd == "text" || cmd == "bg" || cmd == "encode" || cmd == "decode"
                    if (needsEq && !rest.contains("=")) {
                        throw RcError("$cmd me '=' chahiye (jaise: $cmd naam = \"abc\")", ln)
                    }
                    cur().add(Simple(cmd, rest, ln))
                }
            }
        }
        if (stack.isNotEmpty()) throw RcError("if band nahi hua, end likho", stack[stack.size - 1].line)
        return root
    }

    /* ---------------- expressions ---------------- */

    fun tokens(s: String, ln: Int): List<String> {
        val out = ArrayList<String>()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            when {
                c == ' ' || c == '\t' -> i++
                c == '"' -> {
                    val j = s.indexOf('"', i + 1)
                    if (j < 0) throw RcError("quote (\") band nahi hua", ln)
                    out.add(s.substring(i, j + 1))
                    i = j + 1
                }
                c.isDigit() || (c == '.' && i + 1 < s.length && s[i + 1].isDigit()) -> {
                    var j = i
                    while (j < s.length && (s[j].isDigit() || s[j] == '.')) j++
                    out.add(s.substring(i, j))
                    i = j
                }
                c.isLetter() || c == '_' -> {
                    var j = i
                    while (j < s.length && (s[j].isLetterOrDigit() || s[j] == '_')) j++
                    out.add(s.substring(i, j))
                    i = j
                }
                (c == '=' || c == '!' || c == '<' || c == '>') && i + 1 < s.length && s[i + 1] == '=' -> {
                    out.add(s.substring(i, i + 2))
                    i += 2
                }
                c == ',' -> {
                    out.add(",")
                    i++
                }
                "+-*/()<>".indexOf(c) >= 0 -> {
                    out.add(c.toString())
                    i++
                }
                else -> throw RcError("'$c' samajh nahi aaya", ln)
            }
        }
        return out
    }
}

class Interp(private val host: RcHost) {
    val vars = HashMap<String, Any>()
    private var depth = 0

    private class Cur(val t: List<String>, val ln: Int) {
        var i = 0
    }

    fun run(code: String) {
        exec(RcLang.parse(code))
    }

    private fun exec(list: List<Stmt>) {
        for (s in list) step(s)
    }

    private fun step(s: Stmt) {
        when (s) {
            is IfStmt -> if (truthy(s.cond, s.line)) exec(s.thenL) else exec(s.elseL)
            is Simple -> simple(s)
        }
    }

    private fun simple(s: Simple) {
        when (s.cmd) {
            "set" -> {
                val name = s.args.substringBefore('=').trim()
                vars[name] = eval(s.args.substringAfter('=', ""), s.line)
            }
            "toast" -> host.toast(str(eval(s.args, s.line)))
            "text" -> {
                val id = s.args.substringBefore('=').trim()
                host.setText(id, str(eval(s.args.substringAfter('=', ""), s.line)))
            }
            "show" -> host.setVisible(s.args.trim(), true)
            "hide" -> host.setVisible(s.args.trim(), false)
            "bg" -> {
                val id = s.args.substringBefore('=').trim()
                host.setBg(id, str(eval(s.args.substringAfter('=', ""), s.line)))
            }
            "copy" -> host.copy(str(eval(s.args, s.line)))
            "encode" -> {
                val name = s.args.substringBefore('=').trim()
                val rhs = s.args.substringAfter('=', "")
                val toks = RcLang.tokens(rhs, s.line)
                val ci = toks.indexOf(",")
                if (ci < 0) throw RcError("encode me message aur key dono do, comma se alag (jaise: encode code = get msg, key)", s.line)
                val msg = str(evalTokens(toks.subList(0, ci), s.line))
                val keyRaw = str(evalTokens(toks.subList(ci + 1, toks.size), s.line))
                val key = keyRaw.trim().toDoubleOrNull()?.toInt() ?: 0
                vars[name] = Cipher.encode(msg, key)
            }
            "decode" -> {
                val name = s.args.substringBefore('=').trim()
                val rhs = s.args.substringAfter('=', "")
                vars[name] = Cipher.decode(str(eval(rhs, s.line)))
            }
            "screen" -> host.screen(s.args.trim())
            "back" -> host.back()
            "url" -> host.url(str(eval(s.args, s.line)))
            "run" -> {
                val code = host.script(s.args.trim()) ?: throw RcError("script nahi mila: " + s.args.trim(), s.line)
                if (depth > 20) throw RcError("run bahut andar tak gaya", s.line)
                depth++
                try {
                    run(code)
                } finally {
                    depth--
                }
            }
        }
    }

    private fun truthy(cond: String, ln: Int): Boolean {
        val t = RcLang.tokens(cond, ln)
        val ops = listOf("==", "!=", ">=", "<=", ">", "<")
        var at = -1
        var depthP = 0
        for (k in t.indices) {
            if (t[k] == "(") depthP++
            if (t[k] == ")") depthP--
            if (depthP == 0 && t[k] in ops) {
                at = k
                break
            }
        }
        if (at < 0) {
            val v = evalTokens(t, ln)
            val sv = str(v)
            return sv.isNotEmpty() && sv != "0" && sv != "false"
        }
        val a = evalTokens(t.subList(0, at), ln)
        val b = evalTokens(t.subList(at + 1, t.size), ln)
        val na = toNum(a)
        val nb = toNum(b)
        val op = t[at]
        if (na != null && nb != null) {
            return when (op) {
                "==" -> na == nb
                "!=" -> na != nb
                ">=" -> na >= nb
                "<=" -> na <= nb
                ">" -> na > nb
                else -> na < nb
            }
        }
        val sa = str(a)
        val sb = str(b)
        return when (op) {
            "==" -> sa == sb
            "!=" -> sa != sb
            ">=" -> sa >= sb
            "<=" -> sa <= sb
            ">" -> sa > sb
            else -> sa < sb
        }
    }

    private fun toNum(v: Any): Double? = when (v) {
        is Double -> v
        is String -> v.trim().toDoubleOrNull()
        else -> null
    }

    fun str(v: Any): String {
        if (v is Double) {
            return if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString() else v.toString()
        }
        return v.toString()
    }

    private fun eval(expr: String, ln: Int): Any = evalTokens(RcLang.tokens(expr, ln), ln)

    private fun evalTokens(t: List<String>, ln: Int): Any {
        if (t.isEmpty()) throw RcError("expression khali hai", ln)
        val c = Cur(t, ln)
        val v = addSub(c)
        if (c.i < t.size) throw RcError("'" + t[c.i] + "' yahan galat hai", ln)
        return v
    }

    private fun addSub(c: Cur): Any {
        var l = mulDiv(c)
        while (c.i < c.t.size && (c.t[c.i] == "+" || c.t[c.i] == "-")) {
            val op = c.t[c.i]
            c.i++
            val r = mulDiv(c)
            l = if (op == "+") {
                if (l is Double && r is Double) l + r else str(l) + str(r)
            } else {
                val a = toNum(l)
                val b = toNum(r)
                if (a == null || b == null) throw RcError("'-' sirf numbers par chalta hai", c.ln)
                a - b
            }
        }
        return l
    }

    private fun mulDiv(c: Cur): Any {
        var l = atom(c)
        while (c.i < c.t.size && (c.t[c.i] == "*" || c.t[c.i] == "/")) {
            val op = c.t[c.i]
            c.i++
            val r = atom(c)
            val a = toNum(l)
            val b = toNum(r)
            if (a == null || b == null) throw RcError("'$op' sirf numbers par chalta hai", c.ln)
            l = if (op == "*") a * b else (if (b == 0.0) throw RcError("0 se divide nahi hota", c.ln) else a / b)
        }
        return l
    }

    private fun atom(c: Cur): Any {
        if (c.i >= c.t.size) throw RcError("expression adhura hai", c.ln)
        val tk = c.t[c.i]
        c.i++
        if (tk.startsWith("\"")) return tk.substring(1, tk.length - 1)
        if (tk[0].isDigit() || tk[0] == '.') return tk.toDoubleOrNull() ?: throw RcError("number galat: $tk", c.ln)
        if (tk == "(") {
            val v = addSub(c)
            if (c.i >= c.t.size || c.t[c.i] != ")") throw RcError("')' chahiye", c.ln)
            c.i++
            return v
        }
        if (tk == "get") {
            if (c.i >= c.t.size) throw RcError("get ke baad id likho", c.ln)
            val id = c.t[c.i]
            c.i++
            return host.getText(id)
        }
        if (tk[0].isLetter() || tk[0] == '_') return vars[tk] ?: ""
        throw RcError("'$tk' yahan galat hai", c.ln)
    }
}


/**
 * Simple reversible cipher: message ke UTF-8 bytes ko key se shift karke
 * 3-digit decimal groups me badalta hai. Key (0-9) result ke pehle digit me
 * chhup jaati hai, isliye decode ke liye sirf code chahiye, key alag se nahi.
 */
object Cipher {
    fun encode(msg: String, key: Int): String {
        val k = ((key % 10) + 10) % 10
        val bytes = msg.toByteArray(Charsets.UTF_8)
        val sb = StringBuilder()
        sb.append(k)
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            val shifted = (v + k * 7 + 3) % 256
            sb.append(shifted.toString().padStart(3, '0'))
        }
        return sb.toString()
    }

    fun decode(code: String): String {
        val c = code.trim()
        if (c.isEmpty()) return ""
        val k = c[0].digitToIntOrNull() ?: return "Invalid code"
        val rest = c.substring(1)
        if (rest.isEmpty()) return ""
        if (rest.length % 3 != 0) return "Invalid code"
        val bytes = ByteArray(rest.length / 3)
        for (i in bytes.indices) {
            val chunk = rest.substring(i * 3, i * 3 + 3).toIntOrNull() ?: return "Invalid code"
            val orig = ((chunk - k * 7 - 3) % 256 + 256) % 256
            bytes[i] = orig.toByte()
        }
        return try {
            String(bytes, Charsets.UTF_8)
        } catch (e: Exception) {
            "Invalid code"
        }
    }
}
